---
title: "Pathway Enrichment"
author: "Rosalba Giugno"
date: "06/04/2020"
output:
  html_document:
    keep_md: yes
    number_sections: no
    toc: yes
slidy_presentation: default
---


  


## Introduction

Techniques such as high-throughput sequencing and gene/ protein profiling techniques have transformed biological research by enabling comprehensive monitoring of a biological system. Irrespective of the technology used, analysis of high-throughput
data typically yields a list of differentially expressed genes or proteins. This list is extremely useful in identifying genes that may have roles in a given phenomenon or phenotype. However, for many investigators, this list often fails to provide mechanistic insights into the underlying biology of the condition being studied.
In this way, the advent of high-throughput profiling technologies presents a new challenge, that of **extracting meaning from a long list of differentially expressed genes** and proteins.



Genes involved in the same biological processes, functions, or localizations present correlated behaviors in terms of expression  levels, signal intensities, allele occurrences, and so on. 

With the term **Gene sets**  is meant  simple lists of usually functionally related genes without further specification
of relationships between genes.

Genes are grouped in **Pathways**, i.e. graphs where the set of nodes are genes related to a specific  biological function and edges describe the relationships between the genes. Pathways can be interpreted as specific gene sets, typically representing a group of genes that work together in a biological process. 
We have different type of pathways:

**Genetic pathway** a group of interacting genes\
**Metabolic pathway** a series of cellular chemical reactions\
**Signalling pathway** a series of interactions to affect gene expression\

Metabolic pathways such as glycolysis represent biochemical substrate
conversions by specific enzymes. Signaling pathways such as the MAPK signaling pathway
describe signal transduction cascades from receptor proteins to transcription factors, resulting
in activation or inhibition of specific target genes.

**Gene regulatory networks** describe the interplay and effects of regulatory factors (such as
transcription factors and microRNAs) on the expression of their target genes.


![An example of Pathway: Cell Cycle Pathway](CellCycle.png){width=40%}



The aim of **Pathway Enrichment Analysis** is to give a number (score, p-value) to a pathway that reflects if compared to other pathways, there are more genes in the current pathway differentially expressed (up-regulated/downregulated) and which is the probability of observing these changes just by chance.

We use Patways to enrich a set of genes for two main reasons: 1) To reduce data dimensionality and infact we arrange genes into pathways. 2) Helps interpret the data in the context of biological processes, and functions.

Since Pathway analysis reduces complexity and increases explanatory power it  has become the first choice for gaining insight into the underlying biology of differentially expressed genes and proteins. 

Virtually all of the approaches and tools discussed in this lesson are independent of the data generated from most high-throughput technologies, including next-generation sequencing data and the knowledge bases used for pathway annotations. We use gene expression measurements as example data for discussing and explaining various approaches.


## Resources 
GO (http://www.geneontology.org) and KEGG (http://www.genome.jp/kegg) annotations
are most frequently used for the enrichment analysis of functional gene sets. Despite an
increasing number of gene set and pathway databases, they are typically the first choice due
to their long-standing curation and availability for a wide range of species.

The Gene Ontology (GO) consists of three major sub-ontologies that classify gene products
according to molecular function (MF), biological process (BP) and cellular component (CC).
Each ontology consists of GO terms that define MFs, BPs or CCs to which specific genes are
annotated. The terms are organized in a directed acyclic graph, where edges between the
terms represent relationships of different types. They relate the terms according to a parentchild scheme, i.e. parent terms denote more general entities, whereas child terms represent
more specific entities.

The Kyoto Encyclopedia of Genes and Genomes (KEGG) is a collection of manually drawn
pathway maps representing molecular interaction and reaction networks. These pathways
cover a wide range of biochemical processes that can be divided in 7 broad categories:
metabolism, genetic and environmental information processing, cellular processes, organismal systems, human diseases, and drug development. Metabolism and drug development
pathways differ from pathways of the other 5 categories by illustrating reactions between
chemical compounds. Pathways of the other 5 categories illustrate molecular interactions
between genes and gene products


## Three generations of Pathway enrichment methods: ORA, FCS, PT
Existing enrichment methods can be divided into three generations. The following figure summarizes the three generations of enrichment methods.

![](PathwayAnalysisMethods.png){width=100%}


The first generation of methods is centered around the traditionally used overrepresentation analysis, which tests based on the hypergeometric distribution whether genes above a predefined significance threshold are overrepresented in functional gene sets (Over Rappresentation Analysis **ORA** methods). The functional gene sets are the sets of genes in each pathway. ORA methods statistically evaluate the fraction of genes in a particular pathway found among the set of the genes in our experiment showing changes in expression. 

The second generation of methods resolves the restriction to the subset of significant genes, and instead scores the tendency of gene set members to appear rather at the top or bottom of the ranked list of all measured genes (Functional Class Scoring **FCS**). An example of FCS method is **GSEA**: Gene Set Enrichment Analysis. It is frequently used and widely accepted. It uses a Kolmogorov-Smirnov statistic to test whether the ranks of the p -values of genes in a gene set resemble
a uniform distribution. Gene set enrichment analysis (GSEA), testing whether genes of a gene set accumulate
at the top or bottom of the full gene vector ordered by direction and magnitude of
expression change

First and second generation methods have in common that they ignore known interactions between genes, typically uses only the most significant genes and
discards the others, treat each gene equally (i.e. each
gene is independent of the other genes), each pathway is independent of other
pathways, which is erroneous.  Those methods are thus denoted as set-based. 

Methods that do incorporate known interactions belong to the third generation of methods and are denoted as Pathway Topology (**PT**) or network-based.

ORA and FCS methods consider only the number of genes in a pathway to identify significant pathways, and ignore the additional information available from these knowledge bases. Hence, even if the pathways are completely redrawn with new links between the genes, as long as they contain the same set of genes, ORA and FCS will produce the same results. PT methods instead use pathway topology to compute gene-level statistics. This means that if the genes in two paths are linked differently the enrichment or significance will be different. In the following figure, the genes red are over-expressed and blue down-expressed. 

![](PT.png){width=80%}

Any pathway with the same set of genes in ORA will provide the same level of enrichment. Imagine now a pathway where the same genes are connected differently. It is natural to expect topology to change the significance of these genes in each pathway. For example in the two toy pathways below, two genes are DE but they are in different positions in the two pathways (in a genes B and F, in b the same gene B and A). According to your intention, considering the topology of the pathways and assuming that A, B, E, F are all strongly DE which pathway will be more perturbed, i.e. the DE genes will have more effect on the pathway, i.e. the DE genes will have more effect on the function original described by the pathway?

![](PT1.png){width=50%}

## PT Method: SPIA
An example of PT method is SPIA: Signaling Pathway Impact Analysis. It combines
ORA with the probability that expression changes are propagated across the pathway topology. 

Remember that pathways are seen as graphs, where nodes represent genes and edges represent interactions between them. 

SPIA computes an impact factor (IF)  to analyze signaling pathways. It considers the structure and dynamics of an entire pathway by incorporating a number of important biological factors, including changes in gene expression, types of interactions, and the positions of genes in a pathway. 

The impact analysis combines two types of evidence: (i) the **overrepresentation of DE genes** in a given pathway and (ii) the **abnormal perturbation of that pathway**, as measured by propagating measured expression changes across the pathway topology. 

These two aspects are captured by two independent probability values, $P_{NDE}$ and $P_{PERT}$.

$P_{NDE}$ is the result of any ORA or FCS method, in formula $P_{NDE} = P(X>N_{de}|H_0)$.

$P_{NDE}$ captures the significance of a pathway due to an over-representation analysis of the number of DE genes ($N_{de}$) observed on the pathway. 

In the equation above, $H_0$ stands for the null hypothesis, that the genes that appear as DE on a given pathway are completely random. From a biological perspective this would mean that the pathway is not relevant to the condition under study. 

$P_{NDE}$ values are obtained from ORA/FCS methods assuming that Nde (the number of DE genes on the pathway analyzed) follows a hypergeometric distribution with three parameters: the number of all pathway genes present on the array, the number of genes on the array not belonging to the pathway, total number of DE genes. Any of the existing ORA or FCS approaches can be used to calculate $P_{NDE}$, as long as this probability remains independent of the magnitudes of the fold-changes.

$P_{PERT}$ is calculated based on the amount of perturbation measured in each pathway. We define a gene perturbation factor as:


![Gene Pertubation Factor](PF.png){width=30%}

the term $\Delta E(gi)$ represents the signed normalized measured expression change of the gene $g_i$ (log fold-change if two conditions are compared). 

The second term in the above Equation  is the sum of perturbation factors of the genes $g_j$ directly upstream in the pathway(graph) of the target gene $g_i$, normalized by the number of downstream genes of each such gene $N_{ds}(g_j)$. 

The edges in the graph (the pathway) may be associated to weights to capture the properties of various types of relationships among nodes/genes. You can associate -1 for repression and inhibition, and +1 for induction (activation). Please look at KEGG pathways to get familiar with the meaning of pathways nodes and edges. The absolute value of $β_{ij}$ quantifies the strength of the interaction between genes gj and gi (-1, 1 as just described).


Subsequently, the net perturbation accumulation at the level of each gene, $Acc(g_i)$ is computed as the difference between the perturbation factor PF of a gene and its observed log fold-change:

$Acc(g_i)=PF(g_i)-\Delta E(g_i)$

This subtraction is needed to ensure that DE genes not connected with any other genes will not contribute to the second type of evidence since such genes are already taken into consideration in the ORA and captured by $P_{NDE}$.

Because the PF of each gene is defined by a linear equation, the entire pathway is defined as a linear system. Representing a pathway as a linear system also addresses loops in the pathways. The IF of a pathway (pathway-level statistic) is defined as a sum of PF of all genes in a pathway. 


The total net accumulated perturbation in the pathway is computed as $t_A= \sum_i Acc(g_i)$. The second probability, $P_{PERT}$, will be the probability to observe a total accumulated perturbation of the pathway, $T_A$, more extreme than $t_A$ just by chance:
$P_{PERT} = P(T_A \geqslant t_A|H_0)$

The below figure  illustrates the computation of PPERT for a simple 6 gene pathway containing two DE genes. 

![Capturing the topology of the pathways and the position of the gene
through the perturbation analysis](SPIA.png){width=50%}

In (a), gene (F) cannot perturb the activity of other genes; in (b) gene (A) has the ability to influence the activity of all the remaining genes in the pathway, as the topology of the pathway indicates. An ORA would find the two situations equally (in)significant ($P_{NDE} =0.48$ for a set of 20 monitored genes, out of which five are found to be DE). **The perturbation evidence extracted by SPIA will give more significance to the situation in (b) ($P_{PERT} =0.24$), even though fold-changes in (b) are almost twice as small as those in (a) ($P_{PERT} =0.57$).**

The two types of evidence, $P_{NDE}$ and $P_{PERT}$, are finally combined into one global probability value, $P_G= c_i−c_i ·ln(c_i)$, where $c_i = P_{NDE} * P_{PERT}$. 

When several tens of pathways are tested simultaneously, as is the case throughout this study, small PG values can occur also by chance. Therefore, we suggest controlling the false discovery rate (FDR) of the pathway analysis at $\alpha$ set to have the  5% by applying the popular FDR algorithm. 


**PG can be used to rank the pathways!**
The below plot depicts the $P_{NDE}$, $P_{PERT}$, and $P_G$. 

![Two-dimensional plots illustrating the relationship between the two types of evidence considered by SPIA](PG.png){width=30%}

The X-axis shows the overrepresentation evidence, while the Y-axis shows the perturbation evidence. In the top-left plot, areas 2, 3 and 6 together will include pathways that meet
the over-representation criterion (PNDE <α). Areas 1, 2 and 4 together will include pathways that meet the perturbation criterion (PPERT <α). Areas 1, 2, 3 and 5 will include the pathways that meet the combined SPIA criteria (PG<α).


## Enrichment Browser: A Bioconductor package for seamless navigation through combined results of ORA, FCS and PT enrichment analysis

Now we are going to use a R package called EnrichmentBrowser that implements most of the ORA, FCS, and PT methods. You can use a single set or network based method or it allows a straightforward combination of them. Combination of methods has been proven superior to individual methods in different areas of computational biology, as it increases performance and statistical power and biological insights often complement each other. 

Given gene expression data sampling different conditions,cspecific functional gene sets, and optionally a regulatory network of known interactions between genes, the EnrichmentBrowser performs three essential steps: (1) chosen set- and network-based enrichment methods
are executed individually, (2) enriched gene sets are combined by selected ranking criteria, and (3) resulting gene set rankings are displayed as HTML pages for detailed inspection.

![Combine set- & network-based pathway enrichment analysis](EnrBrowser.png){width=40%}

```r
if (!"BiocManager" %in% rownames(installed.packages()))
  install.packages("BiocManager")
BiocManager::install(c("EnrichmentBrowser"))
```

```
## Bioconductor version 3.10 (BiocManager 1.30.10), R 3.6.3 (2020-02-29)
```

```
## Installing package(s) 'EnrichmentBrowser'
```

```
## 
## The downloaded binary packages are in
## 	/var/folders/cr/zmq6t12d715_s5hpq_d6r_wc0000gp/T//RtmpmR4uK7/downloaded_packages
```

```
## Old packages: 'dbplyr', 'haven', 'httpuv', 'nlme', 'reticulate', 'sn'
```




```r
library(EnrichmentBrowser)
```

The package has two main functions, sbea for set based enrichment and nbea for network based enrichment analysis:\,

sbea(method = EnrichmentBrowser::sbeaMethods(), se, gs, alpha = 0.05,
     perm = 1000, padj.method = "none", out.file = NULL,
     browse = FALSE, ...) \,

nbea(method = EnrichmentBrowser::nbeaMethods(), se, gs, grn,
     prune.grn = TRUE, alpha = 0.05, perm = 1000,
     padj.method = "none", out.file = NULL, browse = FALSE, ...)

The above methods take in input  **se** that is an Expression dataset,  i.e. an object of class **SummarizedExperiment**. Mandatory minimal annotations are colData column storing binary group assignment (named "GROUP"), rowData column storing (log2) fold changes of differential expression between sample groups (named "FC"), and rowData column storing adjusted (corrected for multiple testing) p-values of differential expression between sample groups (named "ADJ.PVAL")

### Preprocessing of data to use as example
Let's use the data 'airway' as an example. We will proccess the data as we have learned on the past lessons and do the differential expression analysis before doing the enrichment analysis.\,
Download the data

```r
data(airway, package="airway")
airway
```

```
## class: RangedSummarizedExperiment 
## dim: 64102 8 
## metadata(1): ''
## assays(1): counts
## rownames(64102): ENSG00000000003 ENSG00000000005 ... LRG_98 LRG_99
## rowData names(0):
## colnames(8): SRR1039508 SRR1039509 ... SRR1039520 SRR1039521
## colData names(9): SampleName cell ... Sample BioSample
```

```r
se=assays(airway)
head(assay(airway)) # or assays(se)$count
```

```
##                 SRR1039508 SRR1039509 SRR1039512 SRR1039513 SRR1039516
## ENSG00000000003        679        448        873        408       1138
## ENSG00000000005          0          0          0          0          0
## ENSG00000000419        467        515        621        365        587
## ENSG00000000457        260        211        263        164        245
## ENSG00000000460         60         55         40         35         78
## ENSG00000000938          0          0          2          0          1
##                 SRR1039517 SRR1039520 SRR1039521
## ENSG00000000003       1047        770        572
## ENSG00000000005          0          0          0
## ENSG00000000419        799        417        508
## ENSG00000000457        331        233        229
## ENSG00000000460         63         76         60
## ENSG00000000938          0          0          0
```

```r
rowData(airway)
```

```
## DataFrame with 64102 rows and 0 columns
```

```r
colData(airway)
```

```
## DataFrame with 8 rows and 9 columns
##            SampleName     cell      dex    albut        Run avgLength
##              <factor> <factor> <factor> <factor>   <factor> <integer>
## SRR1039508 GSM1275862   N61311    untrt    untrt SRR1039508       126
## SRR1039509 GSM1275863   N61311      trt    untrt SRR1039509       126
## SRR1039512 GSM1275866  N052611    untrt    untrt SRR1039512       126
## SRR1039513 GSM1275867  N052611      trt    untrt SRR1039513        87
## SRR1039516 GSM1275870  N080611    untrt    untrt SRR1039516       120
## SRR1039517 GSM1275871  N080611      trt    untrt SRR1039517       126
## SRR1039520 GSM1275874  N061011    untrt    untrt SRR1039520       101
## SRR1039521 GSM1275875  N061011      trt    untrt SRR1039521        98
##            Experiment    Sample    BioSample
##              <factor>  <factor>     <factor>
## SRR1039508  SRX384345 SRS508568 SAMN02422669
## SRR1039509  SRX384346 SRS508567 SAMN02422675
## SRR1039512  SRX384349 SRS508571 SAMN02422678
## SRR1039513  SRX384350 SRS508572 SAMN02422670
## SRR1039516  SRX384353 SRS508575 SAMN02422682
## SRR1039517  SRX384354 SRS508576 SAMN02422673
## SRR1039520  SRX384357 SRS508579 SAMN02422683
## SRR1039521  SRX384358 SRS508580 SAMN02422677
```

Subset for only those samples treated with dexamethasone

```r
se[, airway$dex == "trt"]
```

```
## List of length 1
## names(1): counts
```

```r
rowRanges(airway)
```

```
## GRangesList object of length 64102:
## $ENSG00000000003
## GRanges object with 17 ranges and 2 metadata columns:
##        seqnames            ranges strand |   exon_id       exon_name
##           <Rle>         <IRanges>  <Rle> | <integer>     <character>
##    [1]        X 99883667-99884983      - |    667145 ENSE00001459322
##    [2]        X 99885756-99885863      - |    667146 ENSE00000868868
##    [3]        X 99887482-99887565      - |    667147 ENSE00000401072
##    [4]        X 99887538-99887565      - |    667148 ENSE00001849132
##    [5]        X 99888402-99888536      - |    667149 ENSE00003554016
##    ...      ...               ...    ... .       ...             ...
##   [13]        X 99890555-99890743      - |    667156 ENSE00003512331
##   [14]        X 99891188-99891686      - |    667158 ENSE00001886883
##   [15]        X 99891605-99891803      - |    667159 ENSE00001855382
##   [16]        X 99891790-99892101      - |    667160 ENSE00001863395
##   [17]        X 99894942-99894988      - |    667161 ENSE00001828996
##   -------
##   seqinfo: 722 sequences (1 circular) from an unspecified genome
## 
## ...
## <64101 more elements>
```

```r
metadata(airway)
```

```
## [[1]]
## Experiment data
##   Experimenter name: Himes BE 
##   Laboratory: NA 
##   Contact information:  
##   Title: RNA-Seq transcriptome profiling identifies CRISPLD2 as a glucocorticoid responsive gene that modulates cytokine function in airway smooth muscle cells. 
##   URL: http://www.ncbi.nlm.nih.gov/pubmed/24926665 
##   PMIDs: 24926665 
## 
##   Abstract: A 226 word abstract is available. Use 'abstract' method.
```

```r
metadata(airway)$formula = counts ~ dex + albut
metadata(airway)
```

```
## [[1]]
## Experiment data
##   Experimenter name: Himes BE 
##   Laboratory: NA 
##   Contact information:  
##   Title: RNA-Seq transcriptome profiling identifies CRISPLD2 as a glucocorticoid responsive gene that modulates cytokine function in airway smooth muscle cells. 
##   URL: http://www.ncbi.nlm.nih.gov/pubmed/24926665 
##   PMIDs: 24926665 
## 
##   Abstract: A 226 word abstract is available. Use 'abstract' method.
## 
## $formula
## counts ~ dex + albut
```
Remove genes with very low read counts and measurements that are  not mapped to an ENSEMBL gene ID.

```r
airSE = airway[grep("^ENSG", rownames(airway)),]
airSE = airSE[rowMeans(assay(airSE)) > 10,]
dim(airSE)
```

```
## [1] 16055     8
```

```r
dim(airway)
```

```
## [1] 64102     8
```

Normalize the data

```r
norm.air = normalize(airSE, norm.method="quantile")
```

```
## 
## Attaching package: 'Biostrings'
```

```
## The following object is masked from 'package:graph':
## 
##     complement
```

```
## The following object is masked from 'package:base':
## 
##     strsplit
```

GROUP defines the sample groups being contrasted. For the airway dataset, it indicates whether the cell lines have been treated with dexamethasone (1) or not (0).

```r
airSE$GROUP = ifelse(airway$dex == "trt", 1, 0)
table(airSE$GROUP)
```

```
## 
## 0 1 
## 4 4
```

BLOCK defines paired samples or sample blocks, as e.g. for batch effects.

```r
airSE$BLOCK = airway$cell
table(airSE$BLOCK)
```

```
## 
## N052611 N061011 N080611  N61311 
##       2       2       2       2
```
The function of the EnrichmentBrowser package deAna run a DESEQ, i.e. differential expression analysis on the data

```r
airSE = deAna(airSE)
```

```
## No group or design set. Assuming all samples belong to one group.
```

```
## Excluding 1831 genes not satisfying min.cpm threshold
```

```r
rowData(airSE)
```

```
## DataFrame with 14224 rows and 4 columns
##                                  FC         limma.STAT                 PVAL
##                           <numeric>          <numeric>            <numeric>
## ENSG00000000003  -0.400941651579364  -5.97610283075102 0.000272857421583158
## ENSG00000000419   0.187599488643438   2.49460524783897   0.0358873542106615
## ENSG00000000457   0.020999965602642  0.226337623420207    0.826343035507738
## ENSG00000000460  -0.148574954601126 -0.745711046872271    0.476164274754317
## ENSG00000000971   0.403851567563726   5.46706208487259 0.000501982011653062
## ...                             ...                ...                  ...
## ENSG00000273329  -0.208429061332134   -1.1396884799759    0.285831302368329
## ENSG00000273344  0.0182675844779885 0.0890428135893687    0.931131854251824
## ENSG00000273373 -0.0522479738417863 -0.260519987665722    0.800728025911858
## ENSG00000273382  -0.782107711827451  -2.75659525255542   0.0236645056227931
## ENSG00000273486  -0.143803306298018 -0.577112121499941    0.578980204882982
##                            ADJ.PVAL
##                           <numeric>
## ENSG00000000003 0.00255169228441739
## ENSG00000000419   0.089476200927686
## ENSG00000000457   0.882434708294894
## ENSG00000000460   0.604566691431349
## ENSG00000000971 0.00391029142045627
## ...                             ...
## ENSG00000273329   0.420036819694154
## ENSG00000273344     0.9544839647505
## ENSG00000273373   0.865730878729878
## ENSG00000273382  0.0653726797394851
## ENSG00000273486   0.691993482417909
```
Id mapping of the genes in the dataset

```r
head(rownames(airSE))
```

```
## [1] "ENSG00000000003" "ENSG00000000419" "ENSG00000000457" "ENSG00000000460"
## [5] "ENSG00000000971" "ENSG00000001036"
```

```r
airSE = idMap(airSE, org="hsa", from="ENSEMBL", to="ENTREZID")
```

```
## 
```

```
## Encountered 83 from.IDs with >1 corresponding to.ID
```

```
## (the first to.ID was chosen for each of them)
```

```
## Excluded 1697 from.IDs without a corresponding to.ID
```

```
## Encountered 6 to.IDs with >1 from.ID (the first from.ID was chosen for each of them)
```

```r
head(rownames(airSE))
```

```
## [1] "7105"  "8813"  "57147" "55732" "3075"  "2519"
```


## Gene Sets
The function getGenesets can be used to download gene sets from databases such as GO and KEGG. Here, we use the function to download all KEGG pathways for a chosen organism (here: Homo sapiens) as gene sets.
You will see that we will build 337 gene sets.


```r
kegg.gs = getGenesets(org="hsa", db="kegg")
class(kegg.gs)
```

```
## [1] "list"
```

```r
length(kegg.gs)
```

```
## [1] 337
```

```r
head(names(kegg.gs))
```

```
## [1] "hsa00010_Glycolysis_/_Gluconeogenesis"            
## [2] "hsa00020_Citrate_cycle_(TCA_cycle)"               
## [3] "hsa00030_Pentose_phosphate_pathway"               
## [4] "hsa00040_Pentose_and_glucuronate_interconversions"
## [5] "hsa00051_Fructose_and_mannose_metabolism"         
## [6] "hsa00052_Galactose_metabolism"
```

Analogously, the function getGenesets can be used to retrieve GO terms of a selected ontology (here: biological process, BP) as defined in the GO.db annotation package.

```r
go.gs = getGenesets(org="hsa", db="go", go.onto="BP", go.mode="GO.db")
```

```
## 
```

You can use your own genesets.If provided a file, the function parses user-defined gene sets from GMT file format.  

```r
gmt.file = file.path(data.dir, "hsa_kegg_gs.gmt")
hsa.gs = getGenesets(gmt.file)
```


## Set-based enrichment analysis 
To visualize all supoported methods

```r
sbeaMethods()
```

```
##  [1] "ora"        "safe"       "gsea"       "gsa"        "padog"     
##  [6] "globaltest" "roast"      "camera"     "gsva"       "samgs"     
## [11] "ebm"        "mgsa"
```


```r
air.sres = sbea(method="ora", se=airSE, gs=kegg.gs, perm=0)
```
air.sres is a list, containing 6 elements, the method have been applied, the table of results containg all gene sets (significant and not), the number of significant gene sets found, the RangedSummarizedExperiment  with the input gene details (location and expression), the gene sets, and the threshold alpha. 


```r
class(air.sres)
```

```
## [1] "list"
```

```r
names(air.sres)
```

```
## [1] "method"  "res.tbl" "nr.sigs" "se"      "gs"      "alpha"
```

```r
air.sres[1]
```

```
## $method
## [1] "ora"
```

```r
air.sres[2]
```

```
## $res.tbl
## DataFrame with 327 rows and 4 columns
##                                       GENE.SET  NR.GENES NR.SIG.GENES      PVAL
##                                    <character> <numeric>    <numeric> <numeric>
## 1                      hsa04510_Focal_adhesion       159           96  9.21e-10
## 2                 hsa05206_MicroRNAs_in_cancer       132           80   1.9e-08
## 3          hsa04151_PI3K-Akt_signaling_pathway       233          124  1.58e-07
## 4             hsa05205_Proteoglycans_in_cancer       156           89  1.69e-07
## 5                  hsa05200_Pathways_in_cancer       379          185   5.8e-07
## ...                                        ...       ...          ...       ...
## 323         hsa03015_mRNA_surveillance_pathway        78           14         1
## 324 hsa03008_Ribosome_biogenesis_in_eukaryotes        73           10         1
## 325                          hsa03010_Ribosome       124            9         1
## 326                    hsa03020_RNA_polymerase        31            2         1
## 327        hsa03450_Non-homologous_end-joining        11            0         1
```

```r
air.sres[3]
```

```
## $nr.sigs
## [1] 130
```

```r
length(air.sres[4])
```

```
## [1] 1
```

```r
air.sres[5]$gs$hsa05206_MicroRNAs_in_cancer
```

```
##   [1] "10014"  "10018"  "1021"   "10253"  "1026"   "1027"   "1029"   "10297" 
##   [9] "10298"  "10642"  "11186"  "113130" "1387"   "1398"   "1399"   "1545"  
##  [17] "1786"   "1788"   "1789"   "1869"   "1871"   "1945"   "1946"   "1956"  
##  [25] "2033"   "2064"   "2146"   "23405"  "23411"  "23414"  "2475"   "25"    
##  [33] "27086"  "27165"  "27250"  "2744"   "2885"   "3065"   "3066"   "3162"  
##  [41] "3190"   "324"    "3265"   "3371"   "3551"   "3667"   "3678"   "3690"  
##  [49] "3845"   "387"    "3925"   "399694" "4170"   "4193"   "4194"   "4233"  
##  [57] "4363"   "4609"   "472"    "4790"   "4851"   "4853"   "4854"   "4893"  
##  [65] "5154"   "5156"   "5159"   "5243"   "5290"   "5291"   "5292"   "5293"  
##  [73] "5295"   "5328"   "5335"   "54541"  "5578"   "5581"   "5594"   "5595"  
##  [81] "5598"   "5604"   "5605"   "5728"   "5743"   "57521"  "578"    "5894"  
##  [89] "595"    "596"    "5962"   "599"    "6093"   "6464"   "648"    "6541"  
##  [97] "659"    "6624"   "6654"   "6655"   "6659"   "672"    "6774"   "6935"  
## [105] "7042"   "7057"   "7078"   "7148"   "7157"   "7168"   "7329"   "7422"  
## [113] "7430"   "7431"   "7473"   "8091"   "836"    "8434"   "8503"   "8651"  
## [121] "8660"   "894"    "898"    "900"    "90427"  "9252"   "9493"   "960"   
## [129] "9759"   "9839"   "993"    "994"
```

```r
air.sres[6]
```

```
## $alpha
## [1] 0.05
```


### Result visualization and exploration
gsRanking return a DataFrame with gene sets ranked by the corresponding p-value, data are taken from res.tbl, i.e. air.sres[2]. The gsRanking function displays only those gene sets satisfying the chosen significance level threshold.

While such a ranked list is the standard output of existing enrichment tools, the 

```r
gsRanking(air.sres)
```

```
## DataFrame with 130 rows and 4 columns
##                                           GENE.SET  NR.GENES NR.SIG.GENES
##                                        <character> <numeric>    <numeric>
## 1                          hsa04510_Focal_adhesion       159           96
## 2                     hsa05206_MicroRNAs_in_cancer       132           80
## 3              hsa04151_PI3K-Akt_signaling_pathway       233          124
## 4                 hsa05205_Proteoglycans_in_cancer       156           89
## 5                      hsa05200_Pathways_in_cancer       379          185
## ...                                            ...       ...          ...
## 126 hsa04973_Carbohydrate_digestion_and_absorption        21           12
## 127                       hsa00982_Drug_metabolism        30           16
## 128                    hsa04978_Mineral_absorption        30           16
## 129                hsa04979_Cholesterol_metabolism        30           16
## 130            hsa04380_Osteoclast_differentiation        82           38
##          PVAL
##     <numeric>
## 1    9.21e-10
## 2     1.9e-08
## 3    1.58e-07
## 4    1.69e-07
## 5     5.8e-07
## ...       ...
## 126     0.047
## 127    0.0486
## 128    0.0486
## 129    0.0486
## 130    0.0492
```
gsRanking(sbea.res) returns a DataFrame, in the rows you have the gene sets, here the name of pathways, and 4 columns: GENE.SET, NR.GENES, NR.SIG.GENES, PVAL giving the numebr of genes, from your input, found in each pathway and their statistical significance. 

EnrichmentBrowser package provides visualization and interactive exploration of resulting gene sets far beyond that point. By using the eaBrowse function creates a HTML summary from which each gene set can be inspected in detail (this builds on functionality from the ReportingTools package). 


```r
if (!"BiocManager" %in% rownames(installed.packages()))
  install.packages("BiocManager")
BiocManager::install(c("ReportingTools"))
```

```
## Bioconductor version 3.10 (BiocManager 1.30.10), R 3.6.3 (2020-02-29)
```

```
## Installing package(s) 'ReportingTools'
```

```
## 
## The downloaded binary packages are in
## 	/var/folders/cr/zmq6t12d715_s5hpq_d6r_wc0000gp/T//RtmpmR4uK7/downloaded_packages
```

```
## Old packages: 'dbplyr', 'haven', 'httpuv', 'nlme', 'reticulate', 'sn'
```


```r
library("ReportingTools")
eaBrowse(air.sres,nr.show=5)
```


## Network based enrichment analysis 

To visualize all supoported methods

```r
nbeaMethods()
```

```
## [1] "ggea"        "spia"        "pathnet"     "degraph"     "ganpa"      
## [6] "cepa"        "topologygsa" "netgsa"
```

### Gene regulatory network 
There are well-studied processes and organisms for which comprehensive and well-annotated regulatory networks are available, e.g. the RegulonDB for E. coli and Yeastract for S. cerevisiae. However, there are also cases where such a network is missing. A basic workaround is to compile a network from regulations in pathway databases such as KEGG.

```r
#grn = makeExampleData(what="grn", nodes=names(se))
hsa.grn = compileGRN(org="hsa", db="kegg")
```

### Enrichments
Let's start using the method GGEA. The idea of GGEA (Gene graph enrichment analysis) is to evaluate the consistency of known  regulatory interactions with the observed gene expression data. A GGEA graph for a gene set of interest displays the consistency of each interaction in the network that involves a gene set member. 

```r
air.nres = nbea(method="ggea", se=airSE, gs=kegg.gs, grn=hsa.grn)
gsRanking(air.nres)
```

```
## DataFrame with 63 rows and 5 columns
##                                               GENE.SET   NR.RELS RAW.SCORE
##                                            <character> <numeric> <numeric>
## 1           hsa05410_Hypertrophic_cardiomyopathy_(HCM)        17      12.8
## 2                   hsa04930_Type_II_diabetes_mellitus        48      35.4
## 3   hsa04960_Aldosterone-regulated_sodium_reabsorption        32        23
## 4                    hsa04512_ECM-receptor_interaction       248       177
## 5       hsa04973_Carbohydrate_digestion_and_absorption        24      16.8
## ...                                                ...       ...       ...
## 59                     hsa05017_Spinocerebellar_ataxia        40        25
## 60     hsa05100_Bacterial_invasion_of_epithelial_cells       130      78.4
## 61    hsa04080_Neuroactive_ligand-receptor_interaction         9       6.2
## 62                             hsa04976_Bile_secretion        13      8.59
## 63                  hsa04910_Insulin_signaling_pathway       309       183
##     NORM.SCORE      PVAL
##      <numeric> <numeric>
## 1        0.754  0.000999
## 2        0.738  0.000999
## 3        0.717  0.000999
## 4        0.715  0.000999
## 5        0.701  0.000999
## ...        ...       ...
## 59       0.624     0.038
## 60       0.603     0.039
## 61       0.689      0.04
## 62       0.661     0.045
## 63       0.592     0.049
```

```r
par(mfrow=c(1,2))
ggeaGraph(
  gs=kegg.gs[["hsa05416_Viral_myocarditis"]],
  grn=hsa.grn, se=airSE)
ggeaGraphLegend()
```

![](Enrichment_files/figure-html/unnamed-chunk-25-1.png)<!-- -->
The returned item is the same as what we got above using sbea.
The resulting ranking lists, for each statistically significant gene set, the number of relations of the network involving a member of the gene set under study (NR.RELS), the sum of
consistencies over the relations of the set (RAW.SCORE), the score normalized by induced network size (NORM.SCORE = RAW.SCORE / NR.RELS), and the statistical significance of each gene set based on a permutation approach.

In order to use SPIA you have to change the name into the method.  


```r
air.nres = nbea(method="spia", se=airSE, gs=kegg.gs, grn=hsa.grn)
```

```
## 
## Done pathway 1 : RNA transport..
## Done pathway 2 : RNA degradation..
## Done pathway 3 : PPAR signaling pathway..
## Done pathway 4 : Fanconi anemia pathway..
## Done pathway 5 : MAPK signaling pathway..
## Done pathway 6 : ErbB signaling pathway..
## Done pathway 7 : Calcium signaling pathway..
## Done pathway 8 : Cytokine-cytokine receptor int..
## Done pathway 9 : Chemokine signaling pathway..
## Done pathway 10 : NF-kappa B signaling pathway..
## Done pathway 11 : Phosphatidylinositol signaling..
## Done pathway 12 : Neuroactive ligand-receptor in..
## Done pathway 13 : Cell cycle..
## Done pathway 14 : Oocyte meiosis..
## Done pathway 15 : p53 signaling pathway..
## Done pathway 16 : Sulfur relay system..
## Done pathway 17 : SNARE interactions in vesicula..
## Done pathway 18 : Regulation of autophagy..
## Done pathway 19 : Protein processing in endoplas..
## Done pathway 20 : Lysosome..
## Done pathway 21 : mTOR signaling pathway..
## Done pathway 22 : Apoptosis..
## Done pathway 23 : Vascular smooth muscle contrac..
## Done pathway 24 : Wnt signaling pathway..
## Done pathway 25 : Dorso-ventral axis formation..
## Done pathway 26 : Notch signaling pathway..
## Done pathway 27 : Hedgehog signaling pathway..
## Done pathway 28 : TGF-beta signaling pathway..
## Done pathway 29 : Axon guidance..
## Done pathway 30 : VEGF signaling pathway..
## Done pathway 31 : Osteoclast differentiation..
## Done pathway 32 : Focal adhesion..
## Done pathway 33 : ECM-receptor interaction..
## Done pathway 34 : Cell adhesion molecules (CAMs)..
## Done pathway 35 : Adherens junction..
## Done pathway 36 : Tight junction..
## Done pathway 37 : Gap junction..
## Done pathway 38 : Complement and coagulation cas..
## Done pathway 39 : Antigen processing and present..
## Done pathway 40 : Toll-like receptor signaling p..
## Done pathway 41 : NOD-like receptor signaling pa..
## Done pathway 42 : RIG-I-like receptor signaling ..
## Done pathway 43 : Cytosolic DNA-sensing pathway..
## Done pathway 44 : Jak-STAT signaling pathway..
## Done pathway 45 : Natural killer cell mediated c..
## Done pathway 46 : T cell receptor signaling path..
## Done pathway 47 : B cell receptor signaling path..
## Done pathway 48 : Fc epsilon RI signaling pathwa..
## Done pathway 49 : Fc gamma R-mediated phagocytos..
## Done pathway 50 : Leukocyte transendothelial mig..
## Done pathway 51 : Intestinal immune network for ..
## Done pathway 52 : Circadian rhythm - mammal..
## Done pathway 53 : Long-term potentiation..
## Done pathway 54 : Neurotrophin signaling pathway..
## Done pathway 55 : Retrograde endocannabinoid sig..
## Done pathway 56 : Glutamatergic synapse..
## Done pathway 57 : Cholinergic synapse..
## Done pathway 58 : Serotonergic synapse..
## Done pathway 59 : GABAergic synapse..
## Done pathway 60 : Dopaminergic synapse..
## Done pathway 61 : Long-term depression..
## Done pathway 62 : Olfactory transduction..
## Done pathway 63 : Taste transduction..
## Done pathway 64 : Phototransduction..
## Done pathway 65 : Regulation of actin cytoskelet..
## Done pathway 66 : Insulin signaling pathway..
## Done pathway 67 : GnRH signaling pathway..
## Done pathway 68 : Progesterone-mediated oocyte m..
## Done pathway 69 : Melanogenesis..
## Done pathway 70 : Adipocytokine signaling pathwa..
## Done pathway 71 : Type II diabetes mellitus..
## Done pathway 72 : Type I diabetes mellitus..
## Done pathway 73 : Maturity onset diabetes of the..
## Done pathway 74 : Aldosterone-regulated sodium r..
## Done pathway 75 : Endocrine and other factor-reg..
## Done pathway 76 : Vasopressin-regulated water re..
## Done pathway 77 : Salivary secretion..
## Done pathway 78 : Gastric acid secretion..
## Done pathway 79 : Pancreatic secretion..
## Done pathway 80 : Carbohydrate digestion and abs..
## Done pathway 81 : Bile secretion..
## Done pathway 82 : Mineral absorption..
## Done pathway 83 : Alzheimer's disease..
## Done pathway 84 : Parkinson's disease..
## Done pathway 85 : Amyotrophic lateral sclerosis ..
## Done pathway 86 : Huntington's disease..
## Done pathway 87 : Prion diseases..
## Done pathway 88 : Cocaine addiction..
## Done pathway 89 : Amphetamine addiction..
## Done pathway 90 : Morphine addiction..
## Done pathway 91 : Alcoholism..
## Done pathway 92 : Bacterial invasion of epitheli..
## Done pathway 93 : Vibrio cholerae infection..
## Done pathway 94 : Epithelial cell signaling in H..
## Done pathway 95 : Pathogenic Escherichia coli in..
## Done pathway 96 : Shigellosis..
## Done pathway 97 : Salmonella infection..
## Done pathway 98 : Pertussis..
## Done pathway 99 : Legionellosis..
## Done pathway 100 : Leishmaniasis..
## Done pathway 101 : Chagas disease (American trypa..
## Done pathway 102 : African trypanosomiasis..
## Done pathway 103 : Malaria..
## Done pathway 104 : Toxoplasmosis..
## Done pathway 105 : Amoebiasis..
## Done pathway 106 : Staphylococcus aureus infectio..
## Done pathway 107 : Tuberculosis..
## Done pathway 108 : Hepatitis C..
## Done pathway 109 : Measles..
## Done pathway 110 : Influenza A..
## Done pathway 111 : HTLV-I infection..
## Done pathway 112 : Herpes simplex infection..
## Done pathway 113 : Epstein-Barr virus infection..
## Done pathway 114 : Pathways in cancer..
## Done pathway 115 : Transcriptional misregulation ..
## Done pathway 116 : Viral carcinogenesis..
## Done pathway 117 : Colorectal cancer..
## Done pathway 118 : Renal cell carcinoma..
## Done pathway 119 : Pancreatic cancer..
## Done pathway 120 : Endometrial cancer..
## Done pathway 121 : Glioma..
## Done pathway 122 : Prostate cancer..
## Done pathway 123 : Thyroid cancer..
## Done pathway 124 : Basal cell carcinoma..
## Done pathway 125 : Melanoma..
## Done pathway 126 : Bladder cancer..
## Done pathway 127 : Chronic myeloid leukemia..
## Done pathway 128 : Acute myeloid leukemia..
## Done pathway 129 : Small cell lung cancer..
## Done pathway 130 : Non-small cell lung cancer..
## Done pathway 131 : Asthma..
## Done pathway 132 : Autoimmune thyroid disease..
## Done pathway 133 : Systemic lupus erythematosus..
## Done pathway 134 : Rheumatoid arthritis..
## Done pathway 135 : Allograft rejection..
## Done pathway 136 : Graft-versus-host disease..
## Done pathway 137 : Arrhythmogenic right ventricul..
## Done pathway 138 : Dilated cardiomyopathy..
## Done pathway 139 : Viral myocarditis..
```

```
## Finished SPIA analysis
```

```r
gsRanking(air.nres)
```

```
## DataFrame with 29 rows and 6 columns
##                                                               GENE.SET
##                                                            <character>
## 1                                              hsa04510_Focal_adhesion
## 2                                      hsa05222_Small_cell_lung_cancer
## 3                                          hsa05200_Pathways_in_cancer
## 4                                    hsa05220_Chronic_myeloid_leukemia
## 5                            hsa04810_Regulation_of_actin_cytoskeleton
## ...                                                                ...
## 25                                                 hsa05146_Amoebiasis
## 26  hsa04961_Endocrine_and_other_factor-regulated_calcium_reabsorption
## 27                                  hsa04020_Calcium_signaling_pathway
## 28                            hsa04920_Adipocytokine_signaling_pathway
## 29                            hsa04664_Fc_epsilon_RI_signaling_pathway
##          SIZE       NDE     T.ACT    STATUS      PVAL
##     <numeric> <numeric> <numeric> <numeric> <numeric>
## 1         151        90      2.52         1  0.000103
## 2          69        41      27.3         1  0.000214
## 3         232       122      24.9         1   0.00123
## 4          67        42       8.2         1    0.0016
## 5         143        79      13.9         1    0.0023
## ...       ...       ...       ...       ...       ...
## 25         55        33    -0.513        -1    0.0328
## 26         24        14     -5.51        -1    0.0332
## 27         84        45     -5.24        -1    0.0415
## 28         50        29      2.43         1    0.0475
## 29         47        25      16.5         1    0.0483
```

## Combining results 
Different enrichment analysis methods usually result in different gene set rankings for the same dataset. To compare results and detect gene sets that are supported by different methods, the EnrichmentBrowser package allows to combine results from the different set-based and network-based enrichment analysis methods. The combination of results yields a new ranking of the gene sets under investigation by specified ranking criteria, e.g. the average rank across methods. We consider the ORA result and the GGEA result from the previous sections and use the function combResults. The combined result can be detailedly inspected as before and  interactively ranked as depicted with eaBrowse. 


```r
res.list = list(air.sres, air.nres)
comb.res = combResults(res.list)
eaBrowse(comb.res, graph.view=hsa.grn, nr.show=5)
```



## Enrichment of a simple list genes 
For simple genes list enrichment withoud genes expression but having only the name of the genes, tools like DAVID (https://david.ncifcrf.gov) and GeneAnalytics (http://geneanalytics.genecards.org) are more suitable, and it is recommended to use them for this purpose.


# STRINGdb
Proteins and their functional interactions form the backbone of the cellular machinery. Their connectivity network needs to be considered for the full understanding of biological phenomena. 

The STRING database aims to collect, score and integrate all publicly available sources of protein–protein interaction information, and to complement these with computational predictions. Its goal is to achieve a comprehensive and objective global network, including direct (physical) as well as indirect (functional) interactions.

STRING allows also to perform gene-set enrichment analysis on the entire input. STRING implements well-known classification systems such as Gene Ontology and KEGG, but also offers additional, new classification systems based on high-throughput text-mining as well as on a hierarchical clustering of the association network itself. The STRING resource is available online at https://string-db.org/. STRING allows also to expand the input network with neighbouds proteins and to clsuter the final network. You can access STRING by R, web and Cytoscape. 

![](STRINGdb.png){width=100%}




## Load some example expression data 

```r
data(diff_exp_example1)
head(diff_exp_example1)
```

```
##      pvalue    logFC         gene
## 1 0.0001018 3.333461       VSTM2L
## 2 0.0001392 3.822383       TBC1D2
## 3 0.0001720 3.306056        LENG9
## 4 0.0001739 3.024605       TMEM27
## 5 0.0001990 3.854414 LOC100506014
## 6 0.0002393 3.082052       TSPAN1
```
As a first step, we map the gene names to the STRING database identifiers using the ”map” method. In this particular example, we map from gene HUGO names, but our mapping function supports several other common identifiers (e.g. Entrez GeneID, ENSEMBL proteins, RefSeq transcripts ... etc.).

## Map

```r
example1_mapped <- string_db$map( diff_exp_example1, "gene", removeUnmappedRows = TRUE )
```

```
## Warning:  we couldn't map to STRING 14% of your identifiers
```

If you set to FALSE the ”removeUnmappedRows” parameter, than the rows which corresponds to unmapped genes are left and you can manually inspect them. 

## Get_hits and plot
We extract the most significant 200 genes and we produce an image of the STRING network for those. 


```r
hits <- example1_mapped$STRING_id[1:200]  
```
 

```r
#getOption("SweaveHooks")[["fig"]]()
string_db$plot_network( hits )
```

![](Enrichment_files/figure-html/unnamed-chunk-33-1.png)<!-- -->

You can filter by p-value and add a color column  (i.e. green down-regulated gened and red for up-regulated genes)

```r
example1_mapped_pval05 <- string_db$add_diff_exp_color( subset(example1_mapped, pvalue<0.05),  logFcColStr="logFC" ) 
```




## Enrichment
STRING provides a method to compute the enrichment in Gene Ontology (Process, Function and Component), KEGG and Reactome pathways, PubMed publications, UniProt Keywords, and PFAM/INTERPRO/SMART
domains for your set of proteins all in one simple call. The enrichment itself is computed using an hypergeometric test and the FDR is calculated using Benjamini-Hochberg procedure.

```r
enrichment <- string_db$get_enrichment( hits )
head(enrichment, n=20)
```

```
##       term_id proteins hits       pvalue  pvalue_fdr
## 1  GO:0048545      383   15 2.337593e-07 0.000368020
## 2  GO:0006952     1286   28 3.806997e-07 0.000368020
## 3  GO:0002252      405   15 4.756829e-07 0.000368020
## 4  GO:0010466      234   11 1.767763e-06 0.001025745
## 5  GO:0045861      330   12 8.407161e-06 0.003765892
## 6  GO:0010951      228   10 9.735179e-06 0.003765892
## 7  GO:0002443      141    8 1.224368e-05 0.003839606
## 8  GO:0014070      740   18 1.323432e-05 0.003839606
## 9  GO:0052547      374   12 2.908271e-05 0.007500107
## 10 GO:0051346      379   12 3.309928e-05 0.007682342
## 11 GO:0033993      729   17 3.968231e-05 0.008372967
## 12 GO:0001970        2    2 5.704135e-05 0.011032747
## 13 GO:0006958       30    4 7.451848e-05 0.012896707
## 14 GO:1903034      351   11 7.779142e-05 0.012896707
## 15 GO:0052548      357   11 9.041654e-05 0.013809790
## 16 GO:0050727      241    9 9.519890e-05 0.013809790
## 17 GO:0051384      141    7 1.012684e-04 0.013826119
## 18 GO:0097305      303   10 1.085056e-04 0.013991200
## 19 GO:0002455       34    4 1.231677e-04 0.014636975
## 20 GO:0009725      802   17 1.273150e-04 0.014636975
##                                                  term_description
## 1                                     response to steroid hormone
## 2                                                defense response
## 3                                         immune effector process
## 4                       negative regulation of peptidase activity
## 5                              negative regulation of proteolysis
## 6                   negative regulation of endopeptidase activity
## 7                                     leukocyte mediated immunity
## 8                             response to organic cyclic compound
## 9                                regulation of peptidase activity
## 10                      negative regulation of hydrolase activity
## 11                                              response to lipid
## 12   positive regulation of activation of membrane attack complex
## 13                       complement activation, classical pathway
## 14                             regulation of response to wounding
## 15                           regulation of endopeptidase activity
## 16                            regulation of inflammatory response
## 17                                     response to glucocorticoid
## 18                                            response to alcohol
## 19 humoral immune response mediated by circulating immunoglobulin
## 20                                            response to hormone
```

If you have performed your experiment on a predefined set of proteins, it is important to run the enrichment statistics using that set as a background (otherwise you would get a wrong p-value !). Hence,
before to launch the method above, you may want to set the background:
backgroundV <- example1_mapped$STRING_id[1:2000]   


If you just want to know terms are assigned to your set of proteins (and not necessary enriched) you can use ”get annotations” method. This method will output all the terms from most of the categories (the exceptions are KEGG terms due to licensing issues and PubMed due to the size of the output) that are associated with your set of proteins.

```r
annotations <- string_db$get_annotations()
head(annotations, n=20)
```

```
##               STRING_id    term_id category type
## 1  9606.ENSP00000000233 GO:0006810  Process  IEA
## 2  9606.ENSP00000000233 GO:0007154  Process  IEA
## 3  9606.ENSP00000000233 GO:0007165  Process  IEA
## 4  9606.ENSP00000000233 GO:0007264  Process  IEA
## 5  9606.ENSP00000000233 GO:0008104  Process  IEA
## 6  9606.ENSP00000000233 GO:0008150  Process     
## 7  9606.ENSP00000000233 GO:0008152  Process     
## 8  9606.ENSP00000000233 GO:0009987  Process  IEA
## 9  9606.ENSP00000000233 GO:0015031  Process  IEA
## 10 9606.ENSP00000000233 GO:0016192  Process  IEA
## 11 9606.ENSP00000000233 GO:0023052  Process  IEA
## 12 9606.ENSP00000000233 GO:0033036  Process  IEA
## 13 9606.ENSP00000000233 GO:0035556  Process  IEA
## 14 9606.ENSP00000000233 GO:0044699  Process  IEA
## 15 9606.ENSP00000000233 GO:0044700  Process  IEA
## 16 9606.ENSP00000000233 GO:0044763  Process  IEA
## 17 9606.ENSP00000000233 GO:0045184  Process  IEA
## 18 9606.ENSP00000000233 GO:0050789  Process  IEA
## 19 9606.ENSP00000000233 GO:0050794  Process  IEA
## 20 9606.ENSP00000000233 GO:0050896  Process  IEA
```


## Clustering
The iGraph package provides several clustering/community algorithms: ”fastgreedy”, ”walktrap”, ”spinglass”, ”edge.betweenness”. We encapsulate this in an easy-to-use function that returns the clusters
in a list

### get clusters

```r
clustersList <- string_db$get_clusters(example1_mapped$STRING_id[1:600])
```



Plot first 4 clusters

```r
par(mfrow=c(2,2))
for(i in seq(1:4)){
 string_db$plot_network(clustersList[[i]])
}
```

![](Enrichment_files/figure-html/unnamed-chunk-39-1.png)<!-- -->

## Get additoinal proten information 

```r
string_proteins <- string_db$get_proteins()

tp53 = string_db$mp( "tp53" )
atm = string_db$mp( "atm" )
```

Get the neighbors of the two above proteins 

```r
string_db$get_neighbors( c(tp53, atm) )
```

```
##    [1] "9606.ENSP00000003084" "9606.ENSP00000003100" "9606.ENSP00000003302"
##    [4] "9606.ENSP00000005257" "9606.ENSP00000005260" "9606.ENSP00000005340"
##    [7] "9606.ENSP00000006015" "9606.ENSP00000006053" "9606.ENSP00000008391"
##   [10] "9606.ENSP00000009180" "9606.ENSP00000009530" "9606.ENSP00000010404"
##   [13] "9606.ENSP00000011619" "9606.ENSP00000011653" "9606.ENSP00000013034"
##   [16] "9606.ENSP00000013807" "9606.ENSP00000019103" "9606.ENSP00000019317"
##   [19] "9606.ENSP00000020945" "9606.ENSP00000025008" "9606.ENSP00000027335"
##   [22] "9606.ENSP00000037243" "9606.ENSP00000043402" "9606.ENSP00000052754"
##   [25] "9606.ENSP00000053867" "9606.ENSP00000055077" "9606.ENSP00000057513"
##   [28] "9606.ENSP00000075120" "9606.ENSP00000075503" "9606.ENSP00000078429"
##   [31] "9606.ENSP00000078445" "9606.ENSP00000080059" "9606.ENSP00000083182"
##   [34] "9606.ENSP00000085219" "9606.ENSP00000156626" "9606.ENSP00000160262"
##   [37] "9606.ENSP00000161863" "9606.ENSP00000162749" "9606.ENSP00000164227"
##   [40] "9606.ENSP00000166534" "9606.ENSP00000167586" "9606.ENSP00000168712"
##   [43] "9606.ENSP00000170630" "9606.ENSP00000171111" "9606.ENSP00000171887"
##   [46] "9606.ENSP00000172229" "9606.ENSP00000173229" "9606.ENSP00000173898"
##   [49] "9606.ENSP00000174618" "9606.ENSP00000175506" "9606.ENSP00000176183"
##   [52] "9606.ENSP00000177694" "9606.ENSP00000178638" "9606.ENSP00000178640"
##   [55] "9606.ENSP00000179259" "9606.ENSP00000181839" "9606.ENSP00000184266"
##   [58] "9606.ENSP00000184956" "9606.ENSP00000186436" "9606.ENSP00000194118"
##   [61] "9606.ENSP00000196061" "9606.ENSP00000198767" "9606.ENSP00000199764"
##   [64] "9606.ENSP00000200181" "9606.ENSP00000200453" "9606.ENSP00000201031"
##   [67] "9606.ENSP00000201586" "9606.ENSP00000201979" "9606.ENSP00000202017"
##   [70] "9606.ENSP00000202556" "9606.ENSP00000202773" "9606.ENSP00000202788"
##   [73] "9606.ENSP00000202967" "9606.ENSP00000203630" "9606.ENSP00000204517"
##   [76] "9606.ENSP00000204615" "9606.ENSP00000204961" "9606.ENSP00000205143"
##   [79] "9606.ENSP00000205948" "9606.ENSP00000206249" "9606.ENSP00000206765"
##   [82] "9606.ENSP00000209728" "9606.ENSP00000209875" "9606.ENSP00000210313"
##   [85] "9606.ENSP00000211287" "9606.ENSP00000211998" "9606.ENSP00000212015"
##   [88] "9606.ENSP00000215574" "9606.ENSP00000215587" "9606.ENSP00000215631"
##   [91] "9606.ENSP00000215659" "9606.ENSP00000215743" "9606.ENSP00000215754"
##   [94] "9606.ENSP00000215773" "9606.ENSP00000215781" "9606.ENSP00000215829"
##   [97] "9606.ENSP00000215832" "9606.ENSP00000215909" "9606.ENSP00000215941"
##  [100] "9606.ENSP00000216037" "9606.ENSP00000216115" "9606.ENSP00000216117"
##  [103] "9606.ENSP00000216122" "9606.ENSP00000216133" "9606.ENSP00000216160"
##  [106] "9606.ENSP00000216181" "9606.ENSP00000216185" "9606.ENSP00000216225"
##  [109] "9606.ENSP00000216271" "9606.ENSP00000216294" "9606.ENSP00000216297"
##  [112] "9606.ENSP00000216330" "9606.ENSP00000216336" "9606.ENSP00000216341"
##  [115] "9606.ENSP00000216420" "9606.ENSP00000216492" "9606.ENSP00000216639"
##  [118] "9606.ENSP00000216714" "9606.ENSP00000216727" "9606.ENSP00000216733"
##  [121] "9606.ENSP00000216780" "9606.ENSP00000216797" "9606.ENSP00000216807"
##  [124] "9606.ENSP00000216862" "9606.ENSP00000216911" "9606.ENSP00000216951"
##  [127] "9606.ENSP00000217026" "9606.ENSP00000217086" "9606.ENSP00000217109"
##  [130] "9606.ENSP00000217169" "9606.ENSP00000217182" "9606.ENSP00000217185"
##  [133] "9606.ENSP00000217244" "9606.ENSP00000217254" "9606.ENSP00000217305"
##  [136] "9606.ENSP00000217386" "9606.ENSP00000217426" "9606.ENSP00000217893"
##  [139] "9606.ENSP00000217958" "9606.ENSP00000217961" "9606.ENSP00000218089"
##  [142] "9606.ENSP00000218099" "9606.ENSP00000218348" "9606.ENSP00000218388"
##  [145] "9606.ENSP00000218439" "9606.ENSP00000218548" "9606.ENSP00000218758"
##  [148] "9606.ENSP00000218867" "9606.ENSP00000219066" "9606.ENSP00000219070"
##  [151] "9606.ENSP00000219406" "9606.ENSP00000219431" "9606.ENSP00000219454"
##  [154] "9606.ENSP00000219473" "9606.ENSP00000219476" "9606.ENSP00000219479"
##  [157] "9606.ENSP00000219548" "9606.ENSP00000219700" "9606.ENSP00000219746"
##  [160] "9606.ENSP00000219782" "9606.ENSP00000220003" "9606.ENSP00000220062"
##  [163] "9606.ENSP00000220584" "9606.ENSP00000220592" "9606.ENSP00000220616"
##  [166] "9606.ENSP00000220751" "9606.ENSP00000220764" "9606.ENSP00000220772"
##  [169] "9606.ENSP00000220809" "9606.ENSP00000220940" "9606.ENSP00000220966"
##  [172] "9606.ENSP00000221130" "9606.ENSP00000221132" "9606.ENSP00000221419"
##  [175] "9606.ENSP00000221421" "9606.ENSP00000221452" "9606.ENSP00000221476"
##  [178] "9606.ENSP00000221496" "9606.ENSP00000221515" "9606.ENSP00000221801"
##  [181] "9606.ENSP00000221930" "9606.ENSP00000221972" "9606.ENSP00000221980"
##  [184] "9606.ENSP00000222115" "9606.ENSP00000222139" "9606.ENSP00000222248"
##  [187] "9606.ENSP00000222254" "9606.ENSP00000222266" "9606.ENSP00000222270"
##  [190] "9606.ENSP00000222304" "9606.ENSP00000222305" "9606.ENSP00000222308"
##  [193] "9606.ENSP00000222329" "9606.ENSP00000222330" "9606.ENSP00000222381"
##  [196] "9606.ENSP00000222390" "9606.ENSP00000222543" "9606.ENSP00000222553"
##  [199] "9606.ENSP00000222693" "9606.ENSP00000222726" "9606.ENSP00000222823"
##  [202] "9606.ENSP00000223023" "9606.ENSP00000223029" "9606.ENSP00000223095"
##  [205] "9606.ENSP00000223127" "9606.ENSP00000223129" "9606.ENSP00000223190"
##  [208] "9606.ENSP00000223366" "9606.ENSP00000224237" "9606.ENSP00000224764"
##  [211] "9606.ENSP00000224784" "9606.ENSP00000224950" "9606.ENSP00000225174"
##  [214] "9606.ENSP00000225371" "9606.ENSP00000225396" "9606.ENSP00000225402"
##  [217] "9606.ENSP00000225426" "9606.ENSP00000225430" "9606.ENSP00000225474"
##  [220] "9606.ENSP00000225512" "9606.ENSP00000225577" "9606.ENSP00000225603"
##  [223] "9606.ENSP00000225688" "9606.ENSP00000225698" "9606.ENSP00000225724"
##  [226] "9606.ENSP00000225728" "9606.ENSP00000225792" "9606.ENSP00000225823"
##  [229] "9606.ENSP00000225831" "9606.ENSP00000225916" "9606.ENSP00000225941"
##  [232] "9606.ENSP00000225964" "9606.ENSP00000225983" "9606.ENSP00000226207"
##  [235] "9606.ENSP00000226218" "9606.ENSP00000226247" "9606.ENSP00000226279"
##  [238] "9606.ENSP00000226284" "9606.ENSP00000226299" "9606.ENSP00000226574"
##  [241] "9606.ENSP00000226730" "9606.ENSP00000227155" "9606.ENSP00000227163"
##  [244] "9606.ENSP00000227251" "9606.ENSP00000227266" "9606.ENSP00000227378"
##  [247] "9606.ENSP00000227507" "9606.ENSP00000227758" "9606.ENSP00000228280"
##  [250] "9606.ENSP00000228307" "9606.ENSP00000228434" "9606.ENSP00000228463"
##  [253] "9606.ENSP00000228606" "9606.ENSP00000228644" "9606.ENSP00000228682"
##  [256] "9606.ENSP00000228837" "9606.ENSP00000228872" "9606.ENSP00000228918"
##  [259] "9606.ENSP00000228938" "9606.ENSP00000228945" "9606.ENSP00000229135"
##  [262] "9606.ENSP00000229195" "9606.ENSP00000229239" "9606.ENSP00000229251"
##  [265] "9606.ENSP00000229307" "9606.ENSP00000229328" "9606.ENSP00000229335"
##  [268] "9606.ENSP00000229416" "9606.ENSP00000229595" "9606.ENSP00000229769"
##  [271] "9606.ENSP00000229794" "9606.ENSP00000229854" "9606.ENSP00000230354"
##  [274] "9606.ENSP00000230671" "9606.ENSP00000230859" "9606.ENSP00000230882"
##  [277] "9606.ENSP00000230895" "9606.ENSP00000230990" "9606.ENSP00000231004"
##  [280] "9606.ENSP00000231009" "9606.ENSP00000231061" "9606.ENSP00000231121"
##  [283] "9606.ENSP00000231449" "9606.ENSP00000231454" "9606.ENSP00000231487"
##  [286] "9606.ENSP00000231509" "9606.ENSP00000231572" "9606.ENSP00000231656"
##  [289] "9606.ENSP00000231751" "9606.ENSP00000231790" "9606.ENSP00000232014"
##  [292] "9606.ENSP00000232375" "9606.ENSP00000232424" "9606.ENSP00000232458"
##  [295] "9606.ENSP00000232607" "9606.ENSP00000233057" "9606.ENSP00000233143"
##  [298] "9606.ENSP00000233146" "9606.ENSP00000233156" "9606.ENSP00000233202"
##  [301] "9606.ENSP00000233242" "9606.ENSP00000233607" "9606.ENSP00000233809"
##  [304] "9606.ENSP00000233813" "9606.ENSP00000233840" "9606.ENSP00000233893"
##  [307] "9606.ENSP00000234071" "9606.ENSP00000234091" "9606.ENSP00000234170"
##  [310] "9606.ENSP00000234310" "9606.ENSP00000234313" "9606.ENSP00000234347"
##  [313] "9606.ENSP00000234420" "9606.ENSP00000234590" "9606.ENSP00000234626"
##  [316] "9606.ENSP00000234677" "9606.ENSP00000235090" "9606.ENSP00000235310"
##  [319] "9606.ENSP00000235329" "9606.ENSP00000235372" "9606.ENSP00000235382"
##  [322] "9606.ENSP00000236137" "9606.ENSP00000236147" "9606.ENSP00000236671"
##  [325] "9606.ENSP00000236826" "9606.ENSP00000236850" "9606.ENSP00000236959"
##  [328] "9606.ENSP00000237014" "9606.ENSP00000237264" "9606.ENSP00000237283"
##  [331] "9606.ENSP00000237289" "9606.ENSP00000237380" "9606.ENSP00000237527"
##  [334] "9606.ENSP00000237612" "9606.ENSP00000237654" "9606.ENSP00000237858"
##  [337] "9606.ENSP00000238044" "9606.ENSP00000238081" "9606.ENSP00000238628"
##  [340] "9606.ENSP00000238682" "9606.ENSP00000238721" "9606.ENSP00000239144"
##  [343] "9606.ENSP00000239165" "9606.ENSP00000239223" "9606.ENSP00000239243"
##  [346] "9606.ENSP00000239849" "9606.ENSP00000239882" "9606.ENSP00000239938"
##  [349] "9606.ENSP00000240055" "9606.ENSP00000240100" "9606.ENSP00000240316"
##  [352] "9606.ENSP00000240328" "9606.ENSP00000240423" "9606.ENSP00000240488"
##  [355] "9606.ENSP00000240851" "9606.ENSP00000240874" "9606.ENSP00000241014"
##  [358] "9606.ENSP00000241052" "9606.ENSP00000241261" "9606.ENSP00000241337"
##  [361] "9606.ENSP00000241453" "9606.ENSP00000241600" "9606.ENSP00000241651"
##  [364] "9606.ENSP00000242057" "9606.ENSP00000242152" "9606.ENSP00000242159"
##  [367] "9606.ENSP00000242210" "9606.ENSP00000242261" "9606.ENSP00000242285"
##  [370] "9606.ENSP00000242480" "9606.ENSP00000242576" "9606.ENSP00000242728"
##  [373] "9606.ENSP00000242839" "9606.ENSP00000243077" "9606.ENSP00000243344"
##  [376] "9606.ENSP00000243563" "9606.ENSP00000243644" "9606.ENSP00000243786"
##  [379] "9606.ENSP00000243914" "9606.ENSP00000243924" "9606.ENSP00000244007"
##  [382] "9606.ENSP00000244020" "9606.ENSP00000244050" "9606.ENSP00000244137"
##  [385] "9606.ENSP00000244711" "9606.ENSP00000244741" "9606.ENSP00000244745"
##  [388] "9606.ENSP00000244769" "9606.ENSP00000244869" "9606.ENSP00000245157"
##  [391] "9606.ENSP00000245185" "9606.ENSP00000245222" "9606.ENSP00000245255"
##  [394] "9606.ENSP00000245323" "9606.ENSP00000245414" "9606.ENSP00000245451"
##  [397] "9606.ENSP00000245479" "9606.ENSP00000245539" "9606.ENSP00000245541"
##  [400] "9606.ENSP00000245552" "9606.ENSP00000245907" "9606.ENSP00000245919"
##  [403] "9606.ENSP00000245932" "9606.ENSP00000245960" "9606.ENSP00000246229"
##  [406] "9606.ENSP00000246337" "9606.ENSP00000246515" "9606.ENSP00000246533"
##  [409] "9606.ENSP00000246548" "9606.ENSP00000246554" "9606.ENSP00000246635"
##  [412] "9606.ENSP00000246657" "9606.ENSP00000246785" "9606.ENSP00000246792"
##  [415] "9606.ENSP00000246794" "9606.ENSP00000246802" "9606.ENSP00000246868"
##  [418] "9606.ENSP00000246895" "9606.ENSP00000246912" "9606.ENSP00000246949"
##  [421] "9606.ENSP00000247182" "9606.ENSP00000247207" "9606.ENSP00000247219"
##  [424] "9606.ENSP00000247461" "9606.ENSP00000247470" "9606.ENSP00000247668"
##  [427] "9606.ENSP00000247843" "9606.ENSP00000247970" "9606.ENSP00000248071"
##  [430] "9606.ENSP00000248114" "9606.ENSP00000248444" "9606.ENSP00000248553"
##  [433] "9606.ENSP00000248566" "9606.ENSP00000248673" "9606.ENSP00000248923"
##  [436] "9606.ENSP00000248935" "9606.ENSP00000249071" "9606.ENSP00000249075"
##  [439] "9606.ENSP00000249373" "9606.ENSP00000249389" "9606.ENSP00000249396"
##  [442] "9606.ENSP00000249501" "9606.ENSP00000249636" "9606.ENSP00000249749"
##  [445] "9606.ENSP00000249910" "9606.ENSP00000250003" "9606.ENSP00000250018"
##  [448] "9606.ENSP00000250024" "9606.ENSP00000250056" "9606.ENSP00000250092"
##  [451] "9606.ENSP00000250124" "9606.ENSP00000250151" "9606.ENSP00000250378"
##  [454] "9606.ENSP00000250405" "9606.ENSP00000250416" "9606.ENSP00000250448"
##  [457] "9606.ENSP00000250457" "9606.ENSP00000250495" "9606.ENSP00000250559"
##  [460] "9606.ENSP00000250937" "9606.ENSP00000250971" "9606.ENSP00000251047"
##  [463] "9606.ENSP00000251289" "9606.ENSP00000251413" "9606.ENSP00000251453"
##  [466] "9606.ENSP00000251535" "9606.ENSP00000251582" "9606.ENSP00000251810"
##  [469] "9606.ENSP00000251849" "9606.ENSP00000251871" "9606.ENSP00000251968"
##  [472] "9606.ENSP00000252029" "9606.ENSP00000252050" "9606.ENSP00000252137"
##  [475] "9606.ENSP00000252242" "9606.ENSP00000252244" "9606.ENSP00000252456"
##  [478] "9606.ENSP00000252486" "9606.ENSP00000252505" "9606.ENSP00000252506"
##  [481] "9606.ENSP00000252542" "9606.ENSP00000252599" "9606.ENSP00000252674"
##  [484] "9606.ENSP00000252699" "9606.ENSP00000252723" "9606.ENSP00000252785"
##  [487] "9606.ENSP00000252804" "9606.ENSP00000252809" "9606.ENSP00000252818"
##  [490] "9606.ENSP00000252891" "9606.ENSP00000252945" "9606.ENSP00000252951"
##  [493] "9606.ENSP00000252971" "9606.ENSP00000252996" "9606.ENSP00000253023"
##  [496] "9606.ENSP00000253024" "9606.ENSP00000253063" "9606.ENSP00000253255"
##  [499] "9606.ENSP00000253332" "9606.ENSP00000253339" "9606.ENSP00000253392"
##  [502] "9606.ENSP00000253408" "9606.ENSP00000253452" "9606.ENSP00000253496"
##  [505] "9606.ENSP00000253686" "9606.ENSP00000253788" "9606.ENSP00000253792"
##  [508] "9606.ENSP00000253925" "9606.ENSP00000254043" "9606.ENSP00000254066"
##  [511] "9606.ENSP00000254108" "9606.ENSP00000254181" "9606.ENSP00000254190"
##  [514] "9606.ENSP00000254227" "9606.ENSP00000254231" "9606.ENSP00000254286"
##  [517] "9606.ENSP00000254301" "9606.ENSP00000254322" "9606.ENSP00000254325"
##  [520] "9606.ENSP00000254351" "9606.ENSP00000254480" "9606.ENSP00000254488"
##  [523] "9606.ENSP00000254657" "9606.ENSP00000254719" "9606.ENSP00000254722"
##  [526] "9606.ENSP00000254801" "9606.ENSP00000254810" "9606.ENSP00000254846"
##  [529] "9606.ENSP00000254900" "9606.ENSP00000254942" "9606.ENSP00000254958"
##  [532] "9606.ENSP00000255409" "9606.ENSP00000255465" "9606.ENSP00000255499"
##  [535] "9606.ENSP00000255641" "9606.ENSP00000255688" "9606.ENSP00000255977"
##  [538] "9606.ENSP00000256010" "9606.ENSP00000256078" "9606.ENSP00000256104"
##  [541] "9606.ENSP00000256119" "9606.ENSP00000256178" "9606.ENSP00000256196"
##  [544] "9606.ENSP00000256261" "9606.ENSP00000256383" "9606.ENSP00000256442"
##  [547] "9606.ENSP00000256443" "9606.ENSP00000256474" "9606.ENSP00000256495"
##  [550] "9606.ENSP00000256509" "9606.ENSP00000256594" "9606.ENSP00000256637"
##  [553] "9606.ENSP00000256644" "9606.ENSP00000256646" "9606.ENSP00000256759"
##  [556] "9606.ENSP00000256797" "9606.ENSP00000256857" "9606.ENSP00000256897"
##  [559] "9606.ENSP00000256925" "9606.ENSP00000256996" "9606.ENSP00000256999"
##  [562] "9606.ENSP00000257192" "9606.ENSP00000257254" "9606.ENSP00000257290"
##  [565] "9606.ENSP00000257408" "9606.ENSP00000257430" "9606.ENSP00000257497"
##  [568] "9606.ENSP00000257552" "9606.ENSP00000257555" "9606.ENSP00000257566"
##  [571] "9606.ENSP00000257572" "9606.ENSP00000257745" "9606.ENSP00000257749"
##  [574] "9606.ENSP00000257770" "9606.ENSP00000257818" "9606.ENSP00000257857"
##  [577] "9606.ENSP00000257904" "9606.ENSP00000257934" "9606.ENSP00000258080"
##  [580] "9606.ENSP00000258091" "9606.ENSP00000258123" "9606.ENSP00000258281"
##  [583] "9606.ENSP00000258403" "9606.ENSP00000258411" "9606.ENSP00000258415"
##  [586] "9606.ENSP00000258428" "9606.ENSP00000258534" "9606.ENSP00000258729"
##  [589] "9606.ENSP00000258743" "9606.ENSP00000258774" "9606.ENSP00000258821"
##  [592] "9606.ENSP00000258947" "9606.ENSP00000258960" "9606.ENSP00000258962"
##  [595] "9606.ENSP00000259008" "9606.ENSP00000259021" "9606.ENSP00000259119"
##  [598] "9606.ENSP00000259371" "9606.ENSP00000259486" "9606.ENSP00000259526"
##  [601] "9606.ENSP00000259605" "9606.ENSP00000259607" "9606.ENSP00000259631"
##  [604] "9606.ENSP00000259808" "9606.ENSP00000259874" "9606.ENSP00000259915"
##  [607] "9606.ENSP00000259939" "9606.ENSP00000260010" "9606.ENSP00000260045"
##  [610] "9606.ENSP00000260113" "9606.ENSP00000260130" "9606.ENSP00000260227"
##  [613] "9606.ENSP00000260302" "9606.ENSP00000260356" "9606.ENSP00000260363"
##  [616] "9606.ENSP00000260408" "9606.ENSP00000260433" "9606.ENSP00000260442"
##  [619] "9606.ENSP00000260502" "9606.ENSP00000260600" "9606.ENSP00000260630"
##  [622] "9606.ENSP00000260643" "9606.ENSP00000260645" "9606.ENSP00000260665"
##  [625] "9606.ENSP00000260731" "9606.ENSP00000260766" "9606.ENSP00000260810"
##  [628] "9606.ENSP00000260926" "9606.ENSP00000260947" "9606.ENSP00000260970"
##  [631] "9606.ENSP00000260983" "9606.ENSP00000260985" "9606.ENSP00000261017"
##  [634] "9606.ENSP00000261023" "9606.ENSP00000261038" "9606.ENSP00000261070"
##  [637] "9606.ENSP00000261182" "9606.ENSP00000261207" "9606.ENSP00000261245"
##  [640] "9606.ENSP00000261254" "9606.ENSP00000261267" "9606.ENSP00000261302"
##  [643] "9606.ENSP00000261303" "9606.ENSP00000261313" "9606.ENSP00000261318"
##  [646] "9606.ENSP00000261349" "9606.ENSP00000261366" "9606.ENSP00000261402"
##  [649] "9606.ENSP00000261405" "9606.ENSP00000261427" "9606.ENSP00000261434"
##  [652] "9606.ENSP00000261464" "9606.ENSP00000261479" "9606.ENSP00000261531"
##  [655] "9606.ENSP00000261537" "9606.ENSP00000261558" "9606.ENSP00000261584"
##  [658] "9606.ENSP00000261597" "9606.ENSP00000261609" "9606.ENSP00000261622"
##  [661] "9606.ENSP00000261623" "9606.ENSP00000261667" "9606.ENSP00000261681"
##  [664] "9606.ENSP00000261693" "9606.ENSP00000261733" "9606.ENSP00000261769"
##  [667] "9606.ENSP00000261783" "9606.ENSP00000261799" "9606.ENSP00000261879"
##  [670] "9606.ENSP00000261890" "9606.ENSP00000261891" "9606.ENSP00000261900"
##  [673] "9606.ENSP00000261908" "9606.ENSP00000261937" "9606.ENSP00000261991"
##  [676] "9606.ENSP00000262013" "9606.ENSP00000262017" "9606.ENSP00000262039"
##  [679] "9606.ENSP00000262041" "9606.ENSP00000262043" "9606.ENSP00000262053"
##  [682] "9606.ENSP00000262056" "9606.ENSP00000262065" "9606.ENSP00000262077"
##  [685] "9606.ENSP00000262101" "9606.ENSP00000262105" "9606.ENSP00000262120"
##  [688] "9606.ENSP00000262133" "9606.ENSP00000262139" "9606.ENSP00000262158"
##  [691] "9606.ENSP00000262160" "9606.ENSP00000262177" "9606.ENSP00000262178"
##  [694] "9606.ENSP00000262187" "9606.ENSP00000262189" "9606.ENSP00000262219"
##  [697] "9606.ENSP00000262238" "9606.ENSP00000262262" "9606.ENSP00000262269"
##  [700] "9606.ENSP00000262290" "9606.ENSP00000262291" "9606.ENSP00000262294"
##  [703] "9606.ENSP00000262304" "9606.ENSP00000262320" "9606.ENSP00000262367"
##  [706] "9606.ENSP00000262375" "9606.ENSP00000262376" "9606.ENSP00000262395"
##  [709] "9606.ENSP00000262407" "9606.ENSP00000262419" "9606.ENSP00000262435"
##  [712] "9606.ENSP00000262445" "9606.ENSP00000262450" "9606.ENSP00000262461"
##  [715] "9606.ENSP00000262493" "9606.ENSP00000262506" "9606.ENSP00000262518"
##  [718] "9606.ENSP00000262519" "9606.ENSP00000262551" "9606.ENSP00000262584"
##  [721] "9606.ENSP00000262608" "9606.ENSP00000262613" "9606.ENSP00000262623"
##  [724] "9606.ENSP00000262626" "9606.ENSP00000262643" "9606.ENSP00000262662"
##  [727] "9606.ENSP00000262713" "9606.ENSP00000262715" "9606.ENSP00000262719"
##  [730] "9606.ENSP00000262735" "9606.ENSP00000262746" "9606.ENSP00000262768"
##  [733] "9606.ENSP00000262776" "9606.ENSP00000262809" "9606.ENSP00000262854"
##  [736] "9606.ENSP00000262865" "9606.ENSP00000262887" "9606.ENSP00000262894"
##  [739] "9606.ENSP00000262903" "9606.ENSP00000262904" "9606.ENSP00000262948"
##  [742] "9606.ENSP00000262958" "9606.ENSP00000262965" "9606.ENSP00000262971"
##  [745] "9606.ENSP00000262982" "9606.ENSP00000263025" "9606.ENSP00000263043"
##  [748] "9606.ENSP00000263056" "9606.ENSP00000263071" "9606.ENSP00000263083"
##  [751] "9606.ENSP00000263084" "9606.ENSP00000263088" "9606.ENSP00000263100"
##  [754] "9606.ENSP00000263119" "9606.ENSP00000263121" "9606.ENSP00000263174"
##  [757] "9606.ENSP00000263182" "9606.ENSP00000263202" "9606.ENSP00000263209"
##  [760] "9606.ENSP00000263246" "9606.ENSP00000263253" "9606.ENSP00000263257"
##  [763] "9606.ENSP00000263274" "9606.ENSP00000263317" "9606.ENSP00000263321"
##  [766] "9606.ENSP00000263326" "9606.ENSP00000263339" "9606.ENSP00000263341"
##  [769] "9606.ENSP00000263377" "9606.ENSP00000263388" "9606.ENSP00000263390"
##  [772] "9606.ENSP00000263464" "9606.ENSP00000263556" "9606.ENSP00000263574"
##  [775] "9606.ENSP00000263620" "9606.ENSP00000263621" "9606.ENSP00000263635"
##  [778] "9606.ENSP00000263642" "9606.ENSP00000263645" "9606.ENSP00000263663"
##  [781] "9606.ENSP00000263665" "9606.ENSP00000263734" "9606.ENSP00000263735"
##  [784] "9606.ENSP00000263754" "9606.ENSP00000263791" "9606.ENSP00000263795"
##  [787] "9606.ENSP00000263798" "9606.ENSP00000263800" "9606.ENSP00000263826"
##  [790] "9606.ENSP00000263851" "9606.ENSP00000263895" "9606.ENSP00000263897"
##  [793] "9606.ENSP00000263923" "9606.ENSP00000263932" "9606.ENSP00000263946"
##  [796] "9606.ENSP00000263967" "9606.ENSP00000263980" "9606.ENSP00000264001"
##  [799] "9606.ENSP00000264009" "9606.ENSP00000264010" "9606.ENSP00000264012"
##  [802] "9606.ENSP00000264025" "9606.ENSP00000264033" "9606.ENSP00000264036"
##  [805] "9606.ENSP00000264039" "9606.ENSP00000264079" "9606.ENSP00000264093"
##  [808] "9606.ENSP00000264108" "9606.ENSP00000264110" "9606.ENSP00000264126"
##  [811] "9606.ENSP00000264156" "9606.ENSP00000264162" "9606.ENSP00000264187"
##  [814] "9606.ENSP00000264198" "9606.ENSP00000264246" "9606.ENSP00000264316"
##  [817] "9606.ENSP00000264335" "9606.ENSP00000264350" "9606.ENSP00000264376"
##  [820] "9606.ENSP00000264381" "9606.ENSP00000264387" "9606.ENSP00000264389"
##  [823] "9606.ENSP00000264414" "9606.ENSP00000264451" "9606.ENSP00000264487"
##  [826] "9606.ENSP00000264498" "9606.ENSP00000264515" "9606.ENSP00000264552"
##  [829] "9606.ENSP00000264554" "9606.ENSP00000264563" "9606.ENSP00000264595"
##  [832] "9606.ENSP00000264606" "9606.ENSP00000264613" "9606.ENSP00000264634"
##  [835] "9606.ENSP00000264637" "9606.ENSP00000264657" "9606.ENSP00000264664"
##  [838] "9606.ENSP00000264674" "9606.ENSP00000264690" "9606.ENSP00000264708"
##  [841] "9606.ENSP00000264709" "9606.ENSP00000264714" "9606.ENSP00000264716"
##  [844] "9606.ENSP00000264731" "9606.ENSP00000264818" "9606.ENSP00000264832"
##  [847] "9606.ENSP00000264834" "9606.ENSP00000264852" "9606.ENSP00000264867"
##  [850] "9606.ENSP00000264893" "9606.ENSP00000264895" "9606.ENSP00000264896"
##  [853] "9606.ENSP00000264917" "9606.ENSP00000264926" "9606.ENSP00000264932"
##  [856] "9606.ENSP00000264933" "9606.ENSP00000264972" "9606.ENSP00000265023"
##  [859] "9606.ENSP00000265038" "9606.ENSP00000265056" "9606.ENSP00000265070"
##  [862] "9606.ENSP00000265073" "9606.ENSP00000265077" "9606.ENSP00000265081"
##  [865] "9606.ENSP00000265100" "9606.ENSP00000265131" "9606.ENSP00000265132"
##  [868] "9606.ENSP00000265138" "9606.ENSP00000265148" "9606.ENSP00000265162"
##  [871] "9606.ENSP00000265164" "9606.ENSP00000265165" "9606.ENSP00000265195"
##  [874] "9606.ENSP00000265316" "9606.ENSP00000265333" "9606.ENSP00000265335"
##  [877] "9606.ENSP00000265339" "9606.ENSP00000265340" "9606.ENSP00000265351"
##  [880] "9606.ENSP00000265354" "9606.ENSP00000265371" "9606.ENSP00000265372"
##  [883] "9606.ENSP00000265421" "9606.ENSP00000265428" "9606.ENSP00000265433"
##  [886] "9606.ENSP00000265441" "9606.ENSP00000265447" "9606.ENSP00000265462"
##  [889] "9606.ENSP00000265495" "9606.ENSP00000265498" "9606.ENSP00000265689"
##  [892] "9606.ENSP00000265708" "9606.ENSP00000265713" "9606.ENSP00000265723"
##  [895] "9606.ENSP00000265724" "9606.ENSP00000265727" "9606.ENSP00000265734"
##  [898] "9606.ENSP00000265773" "9606.ENSP00000265801" "9606.ENSP00000265849"
##  [901] "9606.ENSP00000265854" "9606.ENSP00000265857" "9606.ENSP00000265870"
##  [904] "9606.ENSP00000265872" "9606.ENSP00000265963" "9606.ENSP00000265983"
##  [907] "9606.ENSP00000266000" "9606.ENSP00000266025" "9606.ENSP00000266041"
##  [910] "9606.ENSP00000266066" "9606.ENSP00000266070" "9606.ENSP00000266079"
##  [913] "9606.ENSP00000266085" "9606.ENSP00000266269" "9606.ENSP00000266458"
##  [916] "9606.ENSP00000266517" "9606.ENSP00000266557" "9606.ENSP00000266659"
##  [919] "9606.ENSP00000266671" "9606.ENSP00000266674" "9606.ENSP00000266688"
##  [922] "9606.ENSP00000266718" "9606.ENSP00000266744" "9606.ENSP00000266970"
##  [925] "9606.ENSP00000266987" "9606.ENSP00000267023" "9606.ENSP00000267101"
##  [928] "9606.ENSP00000267163" "9606.ENSP00000267377" "9606.ENSP00000267502"
##  [931] "9606.ENSP00000267569" "9606.ENSP00000267615" "9606.ENSP00000267803"
##  [934] "9606.ENSP00000267843" "9606.ENSP00000267853" "9606.ENSP00000267953"
##  [937] "9606.ENSP00000267996" "9606.ENSP00000268035" "9606.ENSP00000268058"
##  [940] "9606.ENSP00000268097" "9606.ENSP00000268124" "9606.ENSP00000268171"
##  [943] "9606.ENSP00000268182" "9606.ENSP00000268296" "9606.ENSP00000268605"
##  [946] "9606.ENSP00000268607" "9606.ENSP00000268638" "9606.ENSP00000268712"
##  [949] "9606.ENSP00000268717" "9606.ENSP00000268766" "9606.ENSP00000268957"
##  [952] "9606.ENSP00000269122" "9606.ENSP00000269141" "9606.ENSP00000269216"
##  [955] "9606.ENSP00000269321" "9606.ENSP00000269445" "9606.ENSP00000269571"
##  [958] "9606.ENSP00000269576" "9606.ENSP00000269593" "9606.ENSP00000269980"
##  [961] "9606.ENSP00000270066" "9606.ENSP00000270142" "9606.ENSP00000270162"
##  [964] "9606.ENSP00000270202" "9606.ENSP00000270225" "9606.ENSP00000270233"
##  [967] "9606.ENSP00000270349" "9606.ENSP00000270722" "9606.ENSP00000270861"
##  [970] "9606.ENSP00000271015" "9606.ENSP00000271357" "9606.ENSP00000271638"
##  [973] "9606.ENSP00000271640" "9606.ENSP00000271651" "9606.ENSP00000271751"
##  [976] "9606.ENSP00000271889" "9606.ENSP00000272102" "9606.ENSP00000272163"
##  [979] "9606.ENSP00000272167" "9606.ENSP00000272190" "9606.ENSP00000272233"
##  [982] "9606.ENSP00000272286" "9606.ENSP00000272298" "9606.ENSP00000272317"
##  [985] "9606.ENSP00000272369" "9606.ENSP00000272424" "9606.ENSP00000272430"
##  [988] "9606.ENSP00000272771" "9606.ENSP00000273047" "9606.ENSP00000273063"
##  [991] "9606.ENSP00000273261" "9606.ENSP00000273320" "9606.ENSP00000273430"
##  [994] "9606.ENSP00000273480" "9606.ENSP00000273550" "9606.ENSP00000273853"
##  [997] "9606.ENSP00000273968" "9606.ENSP00000274026" "9606.ENSP00000274031"
## [1000] "9606.ENSP00000274063" "9606.ENSP00000274255" "9606.ENSP00000274289"
## [1003] "9606.ENSP00000274306" "9606.ENSP00000274335" "9606.ENSP00000274376"
## [1006] "9606.ENSP00000274565" "9606.ENSP00000274813" "9606.ENSP00000275428"
## [1009] "9606.ENSP00000275493" "9606.ENSP00000275525" "9606.ENSP00000275603"
## [1012] "9606.ENSP00000275815" "9606.ENSP00000276052" "9606.ENSP00000276072"
## [1015] "9606.ENSP00000276079" "9606.ENSP00000276297" "9606.ENSP00000276344"
## [1018] "9606.ENSP00000276420" "9606.ENSP00000276431" "9606.ENSP00000276440"
## [1021] "9606.ENSP00000276449" "9606.ENSP00000276594" "9606.ENSP00000276603"
## [1024] "9606.ENSP00000276893" "9606.ENSP00000276925" "9606.ENSP00000276927"
## [1027] "9606.ENSP00000277120" "9606.ENSP00000277480" "9606.ENSP00000277508"
## [1030] "9606.ENSP00000277541" "9606.ENSP00000278070" "9606.ENSP00000278175"
## [1033] "9606.ENSP00000278187" "9606.ENSP00000278317" "9606.ENSP00000278379"
## [1036] "9606.ENSP00000278412" "9606.ENSP00000278612" "9606.ENSP00000278616"
## [1039] "9606.ENSP00000278742" "9606.ENSP00000278823" "9606.ENSP00000278903"
## [1042] "9606.ENSP00000278927" "9606.ENSP00000278968" "9606.ENSP00000279022"
## [1045] "9606.ENSP00000279101" "9606.ENSP00000279247" "9606.ENSP00000279387"
## [1048] "9606.ENSP00000279441" "9606.ENSP00000279463" "9606.ENSP00000279488"
## [1051] "9606.ENSP00000279593" "9606.ENSP00000279804" "9606.ENSP00000280154"
## [1054] "9606.ENSP00000280193" "9606.ENSP00000280326" "9606.ENSP00000280357"
## [1057] "9606.ENSP00000280362" "9606.ENSP00000280612" "9606.ENSP00000280614"
## [1060] "9606.ENSP00000280904" "9606.ENSP00000281043" "9606.ENSP00000281171"
## [1063] "9606.ENSP00000281172" "9606.ENSP00000281321" "9606.ENSP00000281537"
## [1066] "9606.ENSP00000281623" "9606.ENSP00000281708" "9606.ENSP00000281821"
## [1069] "9606.ENSP00000281834" "9606.ENSP00000282091" "9606.ENSP00000282397"
## [1072] "9606.ENSP00000282441" "9606.ENSP00000282561" "9606.ENSP00000282728"
## [1075] "9606.ENSP00000282892" "9606.ENSP00000283147" "9606.ENSP00000283179"
## [1078] "9606.ENSP00000283195" "9606.ENSP00000283290" "9606.ENSP00000283635"
## [1081] "9606.ENSP00000283684" "9606.ENSP00000283752" "9606.ENSP00000283875"
## [1084] "9606.ENSP00000283921" "9606.ENSP00000283943" "9606.ENSP00000284000"
## [1087] "9606.ENSP00000284049" "9606.ENSP00000284073" "9606.ENSP00000284202"
## [1090] "9606.ENSP00000284240" "9606.ENSP00000284268" "9606.ENSP00000284273"
## [1093] "9606.ENSP00000284440" "9606.ENSP00000284523" "9606.ENSP00000284601"
## [1096] "9606.ENSP00000284694" "9606.ENSP00000284719" "9606.ENSP00000284811"
## [1099] "9606.ENSP00000284878" "9606.ENSP00000284981" "9606.ENSP00000284984"
## [1102] "9606.ENSP00000285021" "9606.ENSP00000285238" "9606.ENSP00000285279"
## [1105] "9606.ENSP00000285379" "9606.ENSP00000285381" "9606.ENSP00000285398"
## [1108] "9606.ENSP00000285407" "9606.ENSP00000285679" "9606.ENSP00000285735"
## [1111] "9606.ENSP00000285850" "9606.ENSP00000285879" "9606.ENSP00000285930"
## [1114] "9606.ENSP00000286091" "9606.ENSP00000286122" "9606.ENSP00000286186"
## [1117] "9606.ENSP00000286234" "9606.ENSP00000286301" "9606.ENSP00000286332"
## [1120] "9606.ENSP00000286479" "9606.ENSP00000286548" "9606.ENSP00000286574"
## [1123] "9606.ENSP00000286614" "9606.ENSP00000286621" "9606.ENSP00000286648"
## [1126] "9606.ENSP00000286692" "9606.ENSP00000286788" "9606.ENSP00000286800"
## [1129] "9606.ENSP00000286827" "9606.ENSP00000287156" "9606.ENSP00000287239"
## [1132] "9606.ENSP00000287295" "9606.ENSP00000287380" "9606.ENSP00000287598"
## [1135] "9606.ENSP00000287641" "9606.ENSP00000287647" "9606.ENSP00000287820"
## [1138] "9606.ENSP00000287908" "9606.ENSP00000287934" "9606.ENSP00000287936"
## [1141] "9606.ENSP00000288078" "9606.ENSP00000288135" "9606.ENSP00000288167"
## [1144] "9606.ENSP00000288207" "9606.ENSP00000288235" "9606.ENSP00000288266"
## [1147] "9606.ENSP00000288602" "9606.ENSP00000288840" "9606.ENSP00000288943"
## [1150] "9606.ENSP00000288986" "9606.ENSP00000289004" "9606.ENSP00000289081"
## [1153] "9606.ENSP00000289153" "9606.ENSP00000289371" "9606.ENSP00000289473"
## [1156] "9606.ENSP00000290130" "9606.ENSP00000290158" "9606.ENSP00000290167"
## [1159] "9606.ENSP00000290271" "9606.ENSP00000290295" "9606.ENSP00000290299"
## [1162] "9606.ENSP00000290341" "9606.ENSP00000290401" "9606.ENSP00000290551"
## [1165] "9606.ENSP00000290573" "9606.ENSP00000290649" "9606.ENSP00000290650"
## [1168] "9606.ENSP00000290705" "9606.ENSP00000290810" "9606.ENSP00000290866"
## [1171] "9606.ENSP00000290921" "9606.ENSP00000290942" "9606.ENSP00000291009"
## [1174] "9606.ENSP00000291526" "9606.ENSP00000291527" "9606.ENSP00000291547"
## [1177] "9606.ENSP00000291565" "9606.ENSP00000291582" "9606.ENSP00000291700"
## [1180] "9606.ENSP00000291823" "9606.ENSP00000292035" "9606.ENSP00000292095"
## [1183] "9606.ENSP00000292123" "9606.ENSP00000292147" "9606.ENSP00000292169"
## [1186] "9606.ENSP00000292303" "9606.ENSP00000292408" "9606.ENSP00000292431"
## [1189] "9606.ENSP00000292596" "9606.ENSP00000292641" "9606.ENSP00000292823"
## [1192] "9606.ENSP00000292896" "9606.ENSP00000293218" "9606.ENSP00000293230"
## [1195] "9606.ENSP00000293272" "9606.ENSP00000293288" "9606.ENSP00000293308"
## [1198] "9606.ENSP00000293328" "9606.ENSP00000293362" "9606.ENSP00000293549"
## [1201] "9606.ENSP00000293761" "9606.ENSP00000293780" "9606.ENSP00000293805"
## [1204] "9606.ENSP00000293831" "9606.ENSP00000293842" "9606.ENSP00000293897"
## [1207] "9606.ENSP00000294304" "9606.ENSP00000294312" "9606.ENSP00000294339"
## [1210] "9606.ENSP00000294489" "9606.ENSP00000294517" "9606.ENSP00000294702"
## [1213] "9606.ENSP00000294728" "9606.ENSP00000294904" "9606.ENSP00000295006"
## [1216] "9606.ENSP00000295025" "9606.ENSP00000295033" "9606.ENSP00000295108"
## [1219] "9606.ENSP00000295113" "9606.ENSP00000295131" "9606.ENSP00000295213"
## [1222] "9606.ENSP00000295256" "9606.ENSP00000295400" "9606.ENSP00000295470"
## [1225] "9606.ENSP00000295600" "9606.ENSP00000295640" "9606.ENSP00000295641"
## [1228] "9606.ENSP00000295666" "9606.ENSP00000295688" "9606.ENSP00000295731"
## [1231] "9606.ENSP00000295743" "9606.ENSP00000295746" "9606.ENSP00000295756"
## [1234] "9606.ENSP00000295757" "9606.ENSP00000295797" "9606.ENSP00000295872"
## [1237] "9606.ENSP00000295887" "9606.ENSP00000295897" "9606.ENSP00000295901"
## [1240] "9606.ENSP00000296029" "9606.ENSP00000296084" "9606.ENSP00000296140"
## [1243] "9606.ENSP00000296145" "9606.ENSP00000296271" "9606.ENSP00000296273"
## [1246] "9606.ENSP00000296343" "9606.ENSP00000296370" "9606.ENSP00000296412"
## [1249] "9606.ENSP00000296417" "9606.ENSP00000296444" "9606.ENSP00000296456"
## [1252] "9606.ENSP00000296474" "9606.ENSP00000296490" "9606.ENSP00000296503"
## [1255] "9606.ENSP00000296509" "9606.ENSP00000296511" "9606.ENSP00000296522"
## [1258] "9606.ENSP00000296585" "9606.ENSP00000296695" "9606.ENSP00000296754"
## [1261] "9606.ENSP00000296755" "9606.ENSP00000296795" "9606.ENSP00000296861"
## [1264] "9606.ENSP00000296870" "9606.ENSP00000296871" "9606.ENSP00000296930"
## [1267] "9606.ENSP00000297185" "9606.ENSP00000297261" "9606.ENSP00000297268"
## [1270] "9606.ENSP00000297283" "9606.ENSP00000297338" "9606.ENSP00000297350"
## [1273] "9606.ENSP00000297469" "9606.ENSP00000297494" "9606.ENSP00000297785"
## [1276] "9606.ENSP00000297904" "9606.ENSP00000297991" "9606.ENSP00000298048"
## [1279] "9606.ENSP00000298085" "9606.ENSP00000298125" "9606.ENSP00000298139"
## [1282] "9606.ENSP00000298171" "9606.ENSP00000298229" "9606.ENSP00000298283"
## [1285] "9606.ENSP00000298316" "9606.ENSP00000298352" "9606.ENSP00000298492"
## [1288] "9606.ENSP00000298510" "9606.ENSP00000298532" "9606.ENSP00000298552"
## [1291] "9606.ENSP00000298556" "9606.ENSP00000298687" "9606.ENSP00000298743"
## [1294] "9606.ENSP00000298832" "9606.ENSP00000298861" "9606.ENSP00000298902"
## [1297] "9606.ENSP00000298910" "9606.ENSP00000298942" "9606.ENSP00000298999"
## [1300] "9606.ENSP00000299157" "9606.ENSP00000299163" "9606.ENSP00000299206"
## [1303] "9606.ENSP00000299213" "9606.ENSP00000299218" "9606.ENSP00000299259"
## [1306] "9606.ENSP00000299293" "9606.ENSP00000299300" "9606.ENSP00000299333"
## [1309] "9606.ENSP00000299367" "9606.ENSP00000299402" "9606.ENSP00000299421"
## [1312] "9606.ENSP00000299424" "9606.ENSP00000299440" "9606.ENSP00000299502"
## [1315] "9606.ENSP00000299529" "9606.ENSP00000299565" "9606.ENSP00000299575"
## [1318] "9606.ENSP00000299705" "9606.ENSP00000299736" "9606.ENSP00000299759"
## [1321] "9606.ENSP00000299767" "9606.ENSP00000299847" "9606.ENSP00000299855"
## [1324] "9606.ENSP00000299964" "9606.ENSP00000300035" "9606.ENSP00000300060"
## [1327] "9606.ENSP00000300093" "9606.ENSP00000300098" "9606.ENSP00000300134"
## [1330] "9606.ENSP00000300145" "9606.ENSP00000300161" "9606.ENSP00000300177"
## [1333] "9606.ENSP00000300289" "9606.ENSP00000300305" "9606.ENSP00000300403"
## [1336] "9606.ENSP00000300408" "9606.ENSP00000300574" "9606.ENSP00000300589"
## [1339] "9606.ENSP00000300651" "9606.ENSP00000300738" "9606.ENSP00000300900"
## [1342] "9606.ENSP00000300917" "9606.ENSP00000300935" "9606.ENSP00000300952"
## [1345] "9606.ENSP00000301012" "9606.ENSP00000301019" "9606.ENSP00000301030"
## [1348] "9606.ENSP00000301057" "9606.ENSP00000301061" "9606.ENSP00000301067"
## [1351] "9606.ENSP00000301072" "9606.ENSP00000301141" "9606.ENSP00000301178"
## [1354] "9606.ENSP00000301258" "9606.ENSP00000301264" "9606.ENSP00000301419"
## [1357] "9606.ENSP00000301455" "9606.ENSP00000301464" "9606.ENSP00000301522"
## [1360] "9606.ENSP00000301633" "9606.ENSP00000301634" "9606.ENSP00000301653"
## [1363] "9606.ENSP00000301727" "9606.ENSP00000301740" "9606.ENSP00000301761"
## [1366] "9606.ENSP00000301764" "9606.ENSP00000301838" "9606.ENSP00000301904"
## [1369] "9606.ENSP00000301905" "9606.ENSP00000301962" "9606.ENSP00000302100"
## [1372] "9606.ENSP00000302108" "9606.ENSP00000302111" "9606.ENSP00000302120"
## [1375] "9606.ENSP00000302150" "9606.ENSP00000302176" "9606.ENSP00000302216"
## [1378] "9606.ENSP00000302476" "9606.ENSP00000302478" "9606.ENSP00000302486"
## [1381] "9606.ENSP00000302501" "9606.ENSP00000302530" "9606.ENSP00000302564"
## [1384] "9606.ENSP00000302625" "9606.ENSP00000302640" "9606.ENSP00000302665"
## [1387] "9606.ENSP00000302728" "9606.ENSP00000302812" "9606.ENSP00000302830"
## [1390] "9606.ENSP00000302846" "9606.ENSP00000302898" "9606.ENSP00000302951"
## [1393] "9606.ENSP00000302961" "9606.ENSP00000302967" "9606.ENSP00000303158"
## [1396] "9606.ENSP00000303174" "9606.ENSP00000303208" "9606.ENSP00000303211"
## [1399] "9606.ENSP00000303212" "9606.ENSP00000303242" "9606.ENSP00000303315"
## [1402] "9606.ENSP00000303351" "9606.ENSP00000303356" "9606.ENSP00000303394"
## [1405] "9606.ENSP00000303398" "9606.ENSP00000303452" "9606.ENSP00000303507"
## [1408] "9606.ENSP00000303585" "9606.ENSP00000303706" "9606.ENSP00000303709"
## [1411] "9606.ENSP00000303830" "9606.ENSP00000303939" "9606.ENSP00000304102"
## [1414] "9606.ENSP00000304133" "9606.ENSP00000304169" "9606.ENSP00000304226"
## [1417] "9606.ENSP00000304229" "9606.ENSP00000304283" "9606.ENSP00000304290"
## [1420] "9606.ENSP00000304308" "9606.ENSP00000304336" "9606.ENSP00000304447"
## [1423] "9606.ENSP00000304592" "9606.ENSP00000304593" "9606.ENSP00000304669"
## [1426] "9606.ENSP00000304697" "9606.ENSP00000304783" "9606.ENSP00000304802"
## [1429] "9606.ENSP00000304845" "9606.ENSP00000304895" "9606.ENSP00000304903"
## [1432] "9606.ENSP00000304915" "9606.ENSP00000304956" "9606.ENSP00000304994"
## [1435] "9606.ENSP00000305355" "9606.ENSP00000305416" "9606.ENSP00000305422"
## [1438] "9606.ENSP00000305426" "9606.ENSP00000305480" "9606.ENSP00000305556"
## [1441] "9606.ENSP00000305603" "9606.ENSP00000305692" "9606.ENSP00000305714"
## [1444] "9606.ENSP00000305769" "9606.ENSP00000305777" "9606.ENSP00000305906"
## [1447] "9606.ENSP00000305958" "9606.ENSP00000305988" "9606.ENSP00000306100"
## [1450] "9606.ENSP00000306124" "9606.ENSP00000306163" "9606.ENSP00000306185"
## [1453] "9606.ENSP00000306190" "9606.ENSP00000306223" "9606.ENSP00000306245"
## [1456] "9606.ENSP00000306253" "9606.ENSP00000306330" "9606.ENSP00000306356"
## [1459] "9606.ENSP00000306512" "9606.ENSP00000306522" "9606.ENSP00000306561"
## [1462] "9606.ENSP00000306565" "9606.ENSP00000306606" "9606.ENSP00000306670"
## [1465] "9606.ENSP00000306682" "9606.ENSP00000306697" "9606.ENSP00000306752"
## [1468] "9606.ENSP00000306817" "9606.ENSP00000306844" "9606.ENSP00000306884"
## [1471] "9606.ENSP00000306894" "9606.ENSP00000306999" "9606.ENSP00000307046"
## [1474] "9606.ENSP00000307080" "9606.ENSP00000307143" "9606.ENSP00000307156"
## [1477] "9606.ENSP00000307183" "9606.ENSP00000307197" "9606.ENSP00000307235"
## [1480] "9606.ENSP00000307272" "9606.ENSP00000307288" "9606.ENSP00000307297"
## [1483] "9606.ENSP00000307305" "9606.ENSP00000307411" "9606.ENSP00000307491"
## [1486] "9606.ENSP00000307508" "9606.ENSP00000307684" "9606.ENSP00000307713"
## [1489] "9606.ENSP00000307786" "9606.ENSP00000307858" "9606.ENSP00000307859"
## [1492] "9606.ENSP00000307875" "9606.ENSP00000307900" "9606.ENSP00000307940"
## [1495] "9606.ENSP00000308107" "9606.ENSP00000308165" "9606.ENSP00000308176"
## [1498] "9606.ENSP00000308208" "9606.ENSP00000308227" "9606.ENSP00000308383"
## [1501] "9606.ENSP00000308405" "9606.ENSP00000308413" "9606.ENSP00000308450"
## [1504] "9606.ENSP00000308452" "9606.ENSP00000308541" "9606.ENSP00000308583"
## [1507] "9606.ENSP00000308597" "9606.ENSP00000308620" "9606.ENSP00000308720"
## [1510] "9606.ENSP00000308741" "9606.ENSP00000308774" "9606.ENSP00000308895"
## [1513] "9606.ENSP00000308926" "9606.ENSP00000308928" "9606.ENSP00000308937"
## [1516] "9606.ENSP00000308938" "9606.ENSP00000308944" "9606.ENSP00000309124"
## [1519] "9606.ENSP00000309132" "9606.ENSP00000309148" "9606.ENSP00000309163"
## [1522] "9606.ENSP00000309181" "9606.ENSP00000309259" "9606.ENSP00000309336"
## [1525] "9606.ENSP00000309415" "9606.ENSP00000309503" "9606.ENSP00000309570"
## [1528] "9606.ENSP00000309572" "9606.ENSP00000309595" "9606.ENSP00000309629"
## [1531] "9606.ENSP00000309681" "9606.ENSP00000309690" "9606.ENSP00000309710"
## [1534] "9606.ENSP00000309757" "9606.ENSP00000309845" "9606.ENSP00000309871"
## [1537] "9606.ENSP00000309945" "9606.ENSP00000309953" "9606.ENSP00000309968"
## [1540] "9606.ENSP00000310036" "9606.ENSP00000310088" "9606.ENSP00000310127"
## [1543] "9606.ENSP00000310129" "9606.ENSP00000310170" "9606.ENSP00000310219"
## [1546] "9606.ENSP00000310263" "9606.ENSP00000310275" "9606.ENSP00000310301"
## [1549] "9606.ENSP00000310335" "9606.ENSP00000310440" "9606.ENSP00000310447"
## [1552] "9606.ENSP00000310448" "9606.ENSP00000310459" "9606.ENSP00000310490"
## [1555] "9606.ENSP00000310520" "9606.ENSP00000310572" "9606.ENSP00000310585"
## [1558] "9606.ENSP00000310593" "9606.ENSP00000310670" "9606.ENSP00000310686"
## [1561] "9606.ENSP00000310770" "9606.ENSP00000310785" "9606.ENSP00000310842"
## [1564] "9606.ENSP00000310928" "9606.ENSP00000310935" "9606.ENSP00000311005"
## [1567] "9606.ENSP00000311010" "9606.ENSP00000311028" "9606.ENSP00000311032"
## [1570] "9606.ENSP00000311083" "9606.ENSP00000311127" "9606.ENSP00000311165"
## [1573] "9606.ENSP00000311219" "9606.ENSP00000311221" "9606.ENSP00000311280"
## [1576] "9606.ENSP00000311344" "9606.ENSP00000311360" "9606.ENSP00000311430"
## [1579] "9606.ENSP00000311469" "9606.ENSP00000311502" "9606.ENSP00000311505"
## [1582] "9606.ENSP00000311513" "9606.ENSP00000311596" "9606.ENSP00000311697"
## [1585] "9606.ENSP00000311746" "9606.ENSP00000311766" "9606.ENSP00000311778"
## [1588] "9606.ENSP00000311816" "9606.ENSP00000311825" "9606.ENSP00000311827"
## [1591] "9606.ENSP00000311857" "9606.ENSP00000311873" "9606.ENSP00000312027"
## [1594] "9606.ENSP00000312029" "9606.ENSP00000312189" "9606.ENSP00000312326"
## [1597] "9606.ENSP00000312356" "9606.ENSP00000312370" "9606.ENSP00000312436"
## [1600] "9606.ENSP00000312442" "9606.ENSP00000312455" "9606.ENSP00000312506"
## [1603] "9606.ENSP00000312606" "9606.ENSP00000312652" "9606.ENSP00000312664"
## [1606] "9606.ENSP00000312697" "9606.ENSP00000312741" "9606.ENSP00000312789"
## [1609] "9606.ENSP00000312856" "9606.ENSP00000312981" "9606.ENSP00000312987"
## [1612] "9606.ENSP00000312988" "9606.ENSP00000312995" "9606.ENSP00000313007"
## [1615] "9606.ENSP00000313046" "9606.ENSP00000313171" "9606.ENSP00000313199"
## [1618] "9606.ENSP00000313350" "9606.ENSP00000313420" "9606.ENSP00000313437"
## [1621] "9606.ENSP00000313571" "9606.ENSP00000313681" "9606.ENSP00000313740"
## [1624] "9606.ENSP00000313829" "9606.ENSP00000313851" "9606.ENSP00000313854"
## [1627] "9606.ENSP00000314080" "9606.ENSP00000314129" "9606.ENSP00000314132"
## [1630] "9606.ENSP00000314151" "9606.ENSP00000314363" "9606.ENSP00000314407"
## [1633] "9606.ENSP00000314458" "9606.ENSP00000314508" "9606.ENSP00000314543"
## [1636] "9606.ENSP00000314655" "9606.ENSP00000314792" "9606.ENSP00000314810"
## [1639] "9606.ENSP00000314897" "9606.ENSP00000314910" "9606.ENSP00000314946"
## [1642] "9606.ENSP00000314949" "9606.ENSP00000315011" "9606.ENSP00000315130"
## [1645] "9606.ENSP00000315212" "9606.ENSP00000315569" "9606.ENSP00000315602"
## [1648] "9606.ENSP00000315644" "9606.ENSP00000315662" "9606.ENSP00000315664"
## [1651] "9606.ENSP00000315743" "9606.ENSP00000315768" "9606.ENSP00000315870"
## [1654] "9606.ENSP00000315955" "9606.ENSP00000316032" "9606.ENSP00000316114"
## [1657] "9606.ENSP00000316121" "9606.ENSP00000316152" "9606.ENSP00000316176"
## [1660] "9606.ENSP00000316328" "9606.ENSP00000316338" "9606.ENSP00000316357"
## [1663] "9606.ENSP00000316476" "9606.ENSP00000316578" "9606.ENSP00000316729"
## [1666] "9606.ENSP00000316746" "9606.ENSP00000316779" "9606.ENSP00000316786"
## [1669] "9606.ENSP00000316809" "9606.ENSP00000317039" "9606.ENSP00000317272"
## [1672] "9606.ENSP00000317334" "9606.ENSP00000317379" "9606.ENSP00000317385"
## [1675] "9606.ENSP00000317580" "9606.ENSP00000317674" "9606.ENSP00000317817"
## [1678] "9606.ENSP00000317842" "9606.ENSP00000317872" "9606.ENSP00000317985"
## [1681] "9606.ENSP00000317992" "9606.ENSP00000317997" "9606.ENSP00000318057"
## [1684] "9606.ENSP00000318085" "9606.ENSP00000318165" "9606.ENSP00000318176"
## [1687] "9606.ENSP00000318195" "9606.ENSP00000318297" "9606.ENSP00000318351"
## [1690] "9606.ENSP00000318423" "9606.ENSP00000318472" "9606.ENSP00000318486"
## [1693] "9606.ENSP00000318585" "9606.ENSP00000318631" "9606.ENSP00000318646"
## [1696] "9606.ENSP00000318687" "9606.ENSP00000318804" "9606.ENSP00000318820"
## [1699] "9606.ENSP00000318822" "9606.ENSP00000318868" "9606.ENSP00000318902"
## [1702] "9606.ENSP00000318914" "9606.ENSP00000318977" "9606.ENSP00000319053"
## [1705] "9606.ENSP00000319104" "9606.ENSP00000319169" "9606.ENSP00000319279"
## [1708] "9606.ENSP00000319286" "9606.ENSP00000319574" "9606.ENSP00000319635"
## [1711] "9606.ENSP00000319690" "9606.ENSP00000319788" "9606.ENSP00000319831"
## [1714] "9606.ENSP00000319977" "9606.ENSP00000320043" "9606.ENSP00000320130"
## [1717] "9606.ENSP00000320147" "9606.ENSP00000320171" "9606.ENSP00000320180"
## [1720] "9606.ENSP00000320324" "9606.ENSP00000320346" "9606.ENSP00000320347"
## [1723] "9606.ENSP00000320485" "9606.ENSP00000320566" "9606.ENSP00000320663"
## [1726] "9606.ENSP00000320866" "9606.ENSP00000320898" "9606.ENSP00000320935"
## [1729] "9606.ENSP00000320940" "9606.ENSP00000320949" "9606.ENSP00000321070"
## [1732] "9606.ENSP00000321209" "9606.ENSP00000321239" "9606.ENSP00000321260"
## [1735] "9606.ENSP00000321326" "9606.ENSP00000321537" "9606.ENSP00000321636"
## [1738] "9606.ENSP00000321656" "9606.ENSP00000321674" "9606.ENSP00000321703"
## [1741] "9606.ENSP00000321746" "9606.ENSP00000321797" "9606.ENSP00000321835"
## [1744] "9606.ENSP00000322142" "9606.ENSP00000322180" "9606.ENSP00000322341"
## [1747] "9606.ENSP00000322396" "9606.ENSP00000322457" "9606.ENSP00000322542"
## [1750] "9606.ENSP00000322568" "9606.ENSP00000322730" "9606.ENSP00000322775"
## [1753] "9606.ENSP00000322788" "9606.ENSP00000322845" "9606.ENSP00000322898"
## [1756] "9606.ENSP00000322909" "9606.ENSP00000323050" "9606.ENSP00000323065"
## [1759] "9606.ENSP00000323099" "9606.ENSP00000323178" "9606.ENSP00000323183"
## [1762] "9606.ENSP00000323246" "9606.ENSP00000323421" "9606.ENSP00000323511"
## [1765] "9606.ENSP00000323568" "9606.ENSP00000323584" "9606.ENSP00000323588"
## [1768] "9606.ENSP00000323670" "9606.ENSP00000323856" "9606.ENSP00000323889"
## [1771] "9606.ENSP00000324025" "9606.ENSP00000324101" "9606.ENSP00000324173"
## [1774] "9606.ENSP00000324203" "9606.ENSP00000324248" "9606.ENSP00000324277"
## [1777] "9606.ENSP00000324392" "9606.ENSP00000324422" "9606.ENSP00000324464"
## [1780] "9606.ENSP00000324510" "9606.ENSP00000324532" "9606.ENSP00000324549"
## [1783] "9606.ENSP00000324560" "9606.ENSP00000324573" "9606.ENSP00000324648"
## [1786] "9606.ENSP00000324693" "9606.ENSP00000324740" "9606.ENSP00000324742"
## [1789] "9606.ENSP00000324804" "9606.ENSP00000324806" "9606.ENSP00000324856"
## [1792] "9606.ENSP00000324897" "9606.ENSP00000325074" "9606.ENSP00000325120"
## [1795] "9606.ENSP00000325240" "9606.ENSP00000325312" "9606.ENSP00000325376"
## [1798] "9606.ENSP00000325414" "9606.ENSP00000325448" "9606.ENSP00000325527"
## [1801] "9606.ENSP00000325546" "9606.ENSP00000325663" "9606.ENSP00000325677"
## [1804] "9606.ENSP00000325690" "9606.ENSP00000325817" "9606.ENSP00000325819"
## [1807] "9606.ENSP00000325863" "9606.ENSP00000325875" "9606.ENSP00000325905"
## [1810] "9606.ENSP00000325917" "9606.ENSP00000326003" "9606.ENSP00000326031"
## [1813] "9606.ENSP00000326119" "9606.ENSP00000326159" "9606.ENSP00000326170"
## [1816] "9606.ENSP00000326366" "9606.ENSP00000326371" "9606.ENSP00000326381"
## [1819] "9606.ENSP00000326391" "9606.ENSP00000326519" "9606.ENSP00000326550"
## [1822] "9606.ENSP00000326581" "9606.ENSP00000326598" "9606.ENSP00000326804"
## [1825] "9606.ENSP00000327048" "9606.ENSP00000327072" "9606.ENSP00000327213"
## [1828] "9606.ENSP00000327251" "9606.ENSP00000327255" "9606.ENSP00000327513"
## [1831] "9606.ENSP00000327647" "9606.ENSP00000327758" "9606.ENSP00000327801"
## [1834] "9606.ENSP00000327850" "9606.ENSP00000328088" "9606.ENSP00000328169"
## [1837] "9606.ENSP00000328181" "9606.ENSP00000328251" "9606.ENSP00000328287"
## [1840] "9606.ENSP00000328325" "9606.ENSP00000328547" "9606.ENSP00000328732"
## [1843] "9606.ENSP00000328773" "9606.ENSP00000328818" "9606.ENSP00000328858"
## [1846] "9606.ENSP00000328928" "9606.ENSP00000328973" "9606.ENSP00000329117"
## [1849] "9606.ENSP00000329140" "9606.ENSP00000329170" "9606.ENSP00000329213"
## [1852] "9606.ENSP00000329243" "9606.ENSP00000329357" "9606.ENSP00000329411"
## [1855] "9606.ENSP00000329418" "9606.ENSP00000329466" "9606.ENSP00000329539"
## [1858] "9606.ENSP00000329548" "9606.ENSP00000329623" "9606.ENSP00000329668"
## [1861] "9606.ENSP00000329933" "9606.ENSP00000329967" "9606.ENSP00000330032"
## [1864] "9606.ENSP00000330054" "9606.ENSP00000330138" "9606.ENSP00000330221"
## [1867] "9606.ENSP00000330237" "9606.ENSP00000330341" "9606.ENSP00000330343"
## [1870] "9606.ENSP00000330382" "9606.ENSP00000330384" "9606.ENSP00000330572"
## [1873] "9606.ENSP00000330633" "9606.ENSP00000330658" "9606.ENSP00000330825"
## [1876] "9606.ENSP00000330875" "9606.ENSP00000330945" "9606.ENSP00000331019"
## [1879] "9606.ENSP00000331040" "9606.ENSP00000331057" "9606.ENSP00000331103"
## [1882] "9606.ENSP00000331127" "9606.ENSP00000331152" "9606.ENSP00000331167"
## [1885] "9606.ENSP00000331201" "9606.ENSP00000331327" "9606.ENSP00000331358"
## [1888] "9606.ENSP00000331368" "9606.ENSP00000331504" "9606.ENSP00000331514"
## [1891] "9606.ENSP00000331602" "9606.ENSP00000331614" "9606.ENSP00000331736"
## [1894] "9606.ENSP00000331791" "9606.ENSP00000331871" "9606.ENSP00000331879"
## [1897] "9606.ENSP00000331897" "9606.ENSP00000332049" "9606.ENSP00000332116"
## [1900] "9606.ENSP00000332118" "9606.ENSP00000332171" "9606.ENSP00000332194"
## [1903] "9606.ENSP00000332274" "9606.ENSP00000332296" "9606.ENSP00000332353"
## [1906] "9606.ENSP00000332455" "9606.ENSP00000332549" "9606.ENSP00000332643"
## [1909] "9606.ENSP00000332659" "9606.ENSP00000332723" "9606.ENSP00000332737"
## [1912] "9606.ENSP00000332816" "9606.ENSP00000332973" "9606.ENSP00000332979"
## [1915] "9606.ENSP00000332995" "9606.ENSP00000333203" "9606.ENSP00000333298"
## [1918] "9606.ENSP00000333363" "9606.ENSP00000333441" "9606.ENSP00000333487"
## [1921] "9606.ENSP00000333568" "9606.ENSP00000333633" "9606.ENSP00000333685"
## [1924] "9606.ENSP00000333769" "9606.ENSP00000333873" "9606.ENSP00000333926"
## [1927] "9606.ENSP00000333934" "9606.ENSP00000333948" "9606.ENSP00000333994"
## [1930] "9606.ENSP00000334052" "9606.ENSP00000334061" "9606.ENSP00000334122"
## [1933] "9606.ENSP00000334130" "9606.ENSP00000334145" "9606.ENSP00000334294"
## [1936] "9606.ENSP00000334329" "9606.ENSP00000334373" "9606.ENSP00000334458"
## [1939] "9606.ENSP00000334474" "9606.ENSP00000334499" "9606.ENSP00000334928"
## [1942] "9606.ENSP00000335044" "9606.ENSP00000335084" "9606.ENSP00000335153"
## [1945] "9606.ENSP00000335357" "9606.ENSP00000335371" "9606.ENSP00000335620"
## [1948] "9606.ENSP00000335657" "9606.ENSP00000336524" "9606.ENSP00000336528"
## [1951] "9606.ENSP00000336591" "9606.ENSP00000336606" "9606.ENSP00000336607"
## [1954] "9606.ENSP00000336630" "9606.ENSP00000336655" "9606.ENSP00000336701"
## [1957] "9606.ENSP00000336702" "9606.ENSP00000336725" "9606.ENSP00000336750"
## [1960] "9606.ENSP00000336752" "9606.ENSP00000336762" "9606.ENSP00000336783"
## [1963] "9606.ENSP00000336790" "9606.ENSP00000336866" "9606.ENSP00000336868"
## [1966] "9606.ENSP00000336931" "9606.ENSP00000337056" "9606.ENSP00000337065"
## [1969] "9606.ENSP00000337088" "9606.ENSP00000337212" "9606.ENSP00000337261"
## [1972] "9606.ENSP00000337332" "9606.ENSP00000337340" "9606.ENSP00000337353"
## [1975] "9606.ENSP00000337383" "9606.ENSP00000337405" "9606.ENSP00000337439"
## [1978] "9606.ENSP00000337445" "9606.ENSP00000337451" "9606.ENSP00000337459"
## [1981] "9606.ENSP00000337675" "9606.ENSP00000337697" "9606.ENSP00000337746"
## [1984] "9606.ENSP00000337773" "9606.ENSP00000337797" "9606.ENSP00000337825"
## [1987] "9606.ENSP00000337838" "9606.ENSP00000337853" "9606.ENSP00000337915"
## [1990] "9606.ENSP00000338013" "9606.ENSP00000338018" "9606.ENSP00000338020"
## [1993] "9606.ENSP00000338157" "9606.ENSP00000338160" "9606.ENSP00000338235"
## [1996] "9606.ENSP00000338272" "9606.ENSP00000338283" "9606.ENSP00000338345"
## [1999] "9606.ENSP00000338358" "9606.ENSP00000338413" "9606.ENSP00000338548"
## [2002] "9606.ENSP00000338573" "9606.ENSP00000338606" "9606.ENSP00000338673"
## [2005] "9606.ENSP00000338770" "9606.ENSP00000338774" "9606.ENSP00000338814"
## [2008] "9606.ENSP00000338927" "9606.ENSP00000338934" "9606.ENSP00000339001"
## [2011] "9606.ENSP00000339004" "9606.ENSP00000339007" "9606.ENSP00000339027"
## [2014] "9606.ENSP00000339086" "9606.ENSP00000339095" "9606.ENSP00000339136"
## [2017] "9606.ENSP00000339186" "9606.ENSP00000339191" "9606.ENSP00000339250"
## [2020] "9606.ENSP00000339260" "9606.ENSP00000339328" "9606.ENSP00000339428"
## [2023] "9606.ENSP00000339479" "9606.ENSP00000339503" "9606.ENSP00000339527"
## [2026] "9606.ENSP00000339566" "9606.ENSP00000339587" "9606.ENSP00000339787"
## [2029] "9606.ENSP00000339824" "9606.ENSP00000339845" "9606.ENSP00000339917"
## [2032] "9606.ENSP00000339958" "9606.ENSP00000339992" "9606.ENSP00000340019"
## [2035] "9606.ENSP00000340089" "9606.ENSP00000340118" "9606.ENSP00000340210"
## [2038] "9606.ENSP00000340271" "9606.ENSP00000340278" "9606.ENSP00000340281"
## [2041] "9606.ENSP00000340292" "9606.ENSP00000340305" "9606.ENSP00000340330"
## [2044] "9606.ENSP00000340409" "9606.ENSP00000340463" "9606.ENSP00000340507"
## [2047] "9606.ENSP00000340660" "9606.ENSP00000340691" "9606.ENSP00000340698"
## [2050] "9606.ENSP00000340736" "9606.ENSP00000340820" "9606.ENSP00000340874"
## [2053] "9606.ENSP00000340879" "9606.ENSP00000340896" "9606.ENSP00000340944"
## [2056] "9606.ENSP00000340989" "9606.ENSP00000341170" "9606.ENSP00000341189"
## [2059] "9606.ENSP00000341208" "9606.ENSP00000341243" "9606.ENSP00000341268"
## [2062] "9606.ENSP00000341280" "9606.ENSP00000341285" "9606.ENSP00000341289"
## [2065] "9606.ENSP00000341327" "9606.ENSP00000341344" "9606.ENSP00000341390"
## [2068] "9606.ENSP00000341524" "9606.ENSP00000341551" "9606.ENSP00000341674"
## [2071] "9606.ENSP00000341698" "9606.ENSP00000341826" "9606.ENSP00000341882"
## [2074] "9606.ENSP00000341885" "9606.ENSP00000341957" "9606.ENSP00000342007"
## [2077] "9606.ENSP00000342011" "9606.ENSP00000342026" "9606.ENSP00000342032"
## [2080] "9606.ENSP00000342056" "9606.ENSP00000342070" "9606.ENSP00000342082"
## [2083] "9606.ENSP00000342087" "9606.ENSP00000342105" "9606.ENSP00000342121"
## [2086] "9606.ENSP00000342235" "9606.ENSP00000342307" "9606.ENSP00000342343"
## [2089] "9606.ENSP00000342381" "9606.ENSP00000342385" "9606.ENSP00000342560"
## [2092] "9606.ENSP00000342681" "9606.ENSP00000342830" "9606.ENSP00000342905"
## [2095] "9606.ENSP00000342924" "9606.ENSP00000342935" "9606.ENSP00000343001"
## [2098] "9606.ENSP00000343023" "9606.ENSP00000343040" "9606.ENSP00000343129"
## [2101] "9606.ENSP00000343204" "9606.ENSP00000343246" "9606.ENSP00000343313"
## [2104] "9606.ENSP00000343392" "9606.ENSP00000343412" "9606.ENSP00000343445"
## [2107] "9606.ENSP00000343464" "9606.ENSP00000343477" "9606.ENSP00000343515"
## [2110] "9606.ENSP00000343526" "9606.ENSP00000343535" "9606.ENSP00000343552"
## [2113] "9606.ENSP00000343619" "9606.ENSP00000343706" "9606.ENSP00000343741"
## [2116] "9606.ENSP00000343745" "9606.ENSP00000343764" "9606.ENSP00000343785"
## [2119] "9606.ENSP00000343925" "9606.ENSP00000344115" "9606.ENSP00000344173"
## [2122] "9606.ENSP00000344192" "9606.ENSP00000344215" "9606.ENSP00000344220"
## [2125] "9606.ENSP00000344223" "9606.ENSP00000344259" "9606.ENSP00000344352"
## [2128] "9606.ENSP00000344401" "9606.ENSP00000344456" "9606.ENSP00000344460"
## [2131] "9606.ENSP00000344479" "9606.ENSP00000344504" "9606.ENSP00000344544"
## [2134] "9606.ENSP00000344609" "9606.ENSP00000344635" "9606.ENSP00000344666"
## [2137] "9606.ENSP00000344782" "9606.ENSP00000344789" "9606.ENSP00000344818"
## [2140] "9606.ENSP00000344829" "9606.ENSP00000344903" "9606.ENSP00000344909"
## [2143] "9606.ENSP00000344936" "9606.ENSP00000345083" "9606.ENSP00000345096"
## [2146] "9606.ENSP00000345195" "9606.ENSP00000345206" "9606.ENSP00000345230"
## [2149] "9606.ENSP00000345259" "9606.ENSP00000345292" "9606.ENSP00000345344"
## [2152] "9606.ENSP00000345359" "9606.ENSP00000345393" "9606.ENSP00000345464"
## [2155] "9606.ENSP00000345512" "9606.ENSP00000345530" "9606.ENSP00000345571"
## [2158] "9606.ENSP00000345599" "9606.ENSP00000345659" "9606.ENSP00000345681"
## [2161] "9606.ENSP00000345684" "9606.ENSP00000345702" "9606.ENSP00000345708"
## [2164] "9606.ENSP00000345728" "9606.ENSP00000345731" "9606.ENSP00000345771"
## [2167] "9606.ENSP00000345849" "9606.ENSP00000345853" "9606.ENSP00000345873"
## [2170] "9606.ENSP00000346015" "9606.ENSP00000346027" "9606.ENSP00000346032"
## [2173] "9606.ENSP00000346045" "9606.ENSP00000346050" "9606.ENSP00000346067"
## [2176] "9606.ENSP00000346120" "9606.ENSP00000346148" "9606.ENSP00000346294"
## [2179] "9606.ENSP00000346300" "9606.ENSP00000346316" "9606.ENSP00000346340"
## [2182] "9606.ENSP00000346389" "9606.ENSP00000346402" "9606.ENSP00000346437"
## [2185] "9606.ENSP00000346440" "9606.ENSP00000346508" "9606.ENSP00000346550"
## [2188] "9606.ENSP00000346671" "9606.ENSP00000346694" "9606.ENSP00000346697"
## [2191] "9606.ENSP00000346725" "9606.ENSP00000346810" "9606.ENSP00000346839"
## [2194] "9606.ENSP00000346879" "9606.ENSP00000346890" "9606.ENSP00000346921"
## [2197] "9606.ENSP00000346997" "9606.ENSP00000347088" "9606.ENSP00000347168"
## [2200] "9606.ENSP00000347169" "9606.ENSP00000347184" "9606.ENSP00000347232"
## [2203] "9606.ENSP00000347251" "9606.ENSP00000347271" "9606.ENSP00000347379"
## [2206] "9606.ENSP00000347409" "9606.ENSP00000347427" "9606.ENSP00000347433"
## [2209] "9606.ENSP00000347546" "9606.ENSP00000347602" "9606.ENSP00000347665"
## [2212] "9606.ENSP00000347733" "9606.ENSP00000347858" "9606.ENSP00000347890"
## [2215] "9606.ENSP00000347916" "9606.ENSP00000347942" "9606.ENSP00000347978"
## [2218] "9606.ENSP00000347979" "9606.ENSP00000347988" "9606.ENSP00000348019"
## [2221] "9606.ENSP00000348020" "9606.ENSP00000348068" "9606.ENSP00000348069"
## [2224] "9606.ENSP00000348089" "9606.ENSP00000348099" "9606.ENSP00000348108"
## [2227] "9606.ENSP00000348170" "9606.ENSP00000348258" "9606.ENSP00000348300"
## [2230] "9606.ENSP00000348419" "9606.ENSP00000348455" "9606.ENSP00000348461"
## [2233] "9606.ENSP00000348510" "9606.ENSP00000348538" "9606.ENSP00000348550"
## [2236] "9606.ENSP00000348554" "9606.ENSP00000348573" "9606.ENSP00000348577"
## [2239] "9606.ENSP00000348578" "9606.ENSP00000348769" "9606.ENSP00000348784"
## [2242] "9606.ENSP00000348786" "9606.ENSP00000348812" "9606.ENSP00000348822"
## [2245] "9606.ENSP00000348827" "9606.ENSP00000348838" "9606.ENSP00000348849"
## [2248] "9606.ENSP00000348918" "9606.ENSP00000348959" "9606.ENSP00000349003"
## [2251] "9606.ENSP00000349085" "9606.ENSP00000349131" "9606.ENSP00000349156"
## [2254] "9606.ENSP00000349168" "9606.ENSP00000349252" "9606.ENSP00000349275"
## [2257] "9606.ENSP00000349313" "9606.ENSP00000349324" "9606.ENSP00000349393"
## [2260] "9606.ENSP00000349428" "9606.ENSP00000349437" "9606.ENSP00000349508"
## [2263] "9606.ENSP00000349547" "9606.ENSP00000349577" "9606.ENSP00000349594"
## [2266] "9606.ENSP00000349722" "9606.ENSP00000349723" "9606.ENSP00000349770"
## [2269] "9606.ENSP00000349823" "9606.ENSP00000349887" "9606.ENSP00000349959"
## [2272] "9606.ENSP00000349960" "9606.ENSP00000349977" "9606.ENSP00000350028"
## [2275] "9606.ENSP00000350052" "9606.ENSP00000350159" "9606.ENSP00000350198"
## [2278] "9606.ENSP00000350249" "9606.ENSP00000350265" "9606.ENSP00000350369"
## [2281] "9606.ENSP00000350387" "9606.ENSP00000350467" "9606.ENSP00000350491"
## [2284] "9606.ENSP00000350512" "9606.ENSP00000350547" "9606.ENSP00000350708"
## [2287] "9606.ENSP00000350720" "9606.ENSP00000350767" "9606.ENSP00000350785"
## [2290] "9606.ENSP00000350844" "9606.ENSP00000350894" "9606.ENSP00000350896"
## [2293] "9606.ENSP00000350937" "9606.ENSP00000350941" "9606.ENSP00000351015"
## [2296] "9606.ENSP00000351049" "9606.ENSP00000351137" "9606.ENSP00000351209"
## [2299] "9606.ENSP00000351250" "9606.ENSP00000351255" "9606.ENSP00000351273"
## [2302] "9606.ENSP00000351284" "9606.ENSP00000351395" "9606.ENSP00000351407"
## [2305] "9606.ENSP00000351410" "9606.ENSP00000351446" "9606.ENSP00000351490"
## [2308] "9606.ENSP00000351492" "9606.ENSP00000351524" "9606.ENSP00000351575"
## [2311] "9606.ENSP00000351602" "9606.ENSP00000351686" "9606.ENSP00000351697"
## [2314] "9606.ENSP00000351755" "9606.ENSP00000351777" "9606.ENSP00000351885"
## [2317] "9606.ENSP00000351894" "9606.ENSP00000351905" "9606.ENSP00000351908"
## [2320] "9606.ENSP00000352011" "9606.ENSP00000352101" "9606.ENSP00000352121"
## [2323] "9606.ENSP00000352157" "9606.ENSP00000352162" "9606.ENSP00000352173"
## [2326] "9606.ENSP00000352185" "9606.ENSP00000352257" "9606.ENSP00000352264"
## [2329] "9606.ENSP00000352271" "9606.ENSP00000352400" "9606.ENSP00000352424"
## [2332] "9606.ENSP00000352438" "9606.ENSP00000352516" "9606.ENSP00000352561"
## [2335] "9606.ENSP00000352565" "9606.ENSP00000352572" "9606.ENSP00000352608"
## [2338] "9606.ENSP00000352673" "9606.ENSP00000352738" "9606.ENSP00000352834"
## [2341] "9606.ENSP00000352835" "9606.ENSP00000352852" "9606.ENSP00000352929"
## [2344] "9606.ENSP00000352936" "9606.ENSP00000352980" "9606.ENSP00000353089"
## [2347] "9606.ENSP00000353094" "9606.ENSP00000353104" "9606.ENSP00000353157"
## [2350] "9606.ENSP00000353224" "9606.ENSP00000353238" "9606.ENSP00000353344"
## [2353] "9606.ENSP00000353362" "9606.ENSP00000353375" "9606.ENSP00000353401"
## [2356] "9606.ENSP00000353408" "9606.ENSP00000353415" "9606.ENSP00000353427"
## [2359] "9606.ENSP00000353452" "9606.ENSP00000353472" "9606.ENSP00000353475"
## [2362] "9606.ENSP00000353483" "9606.ENSP00000353508" "9606.ENSP00000353582"
## [2365] "9606.ENSP00000353608" "9606.ENSP00000353622" "9606.ENSP00000353624"
## [2368] "9606.ENSP00000353654" "9606.ENSP00000353660" "9606.ENSP00000353679"
## [2371] "9606.ENSP00000353720" "9606.ENSP00000353731" "9606.ENSP00000353735"
## [2374] "9606.ENSP00000353770" "9606.ENSP00000353820" "9606.ENSP00000353863"
## [2377] "9606.ENSP00000353874" "9606.ENSP00000353878" "9606.ENSP00000353904"
## [2380] "9606.ENSP00000354003" "9606.ENSP00000354033" "9606.ENSP00000354040"
## [2383] "9606.ENSP00000354107" "9606.ENSP00000354130" "9606.ENSP00000354152"
## [2386] "9606.ENSP00000354159" "9606.ENSP00000354207" "9606.ENSP00000354218"
## [2389] "9606.ENSP00000354219" "9606.ENSP00000354280" "9606.ENSP00000354313"
## [2392] "9606.ENSP00000354361" "9606.ENSP00000354394" "9606.ENSP00000354432"
## [2395] "9606.ENSP00000354453" "9606.ENSP00000354476" "9606.ENSP00000354487"
## [2398] "9606.ENSP00000354499" "9606.ENSP00000354511" "9606.ENSP00000354522"
## [2401] "9606.ENSP00000354554" "9606.ENSP00000354558" "9606.ENSP00000354586"
## [2404] "9606.ENSP00000354612" "9606.ENSP00000354621" "9606.ENSP00000354660"
## [2407] "9606.ENSP00000354669" "9606.ENSP00000354687" "9606.ENSP00000354718"
## [2410] "9606.ENSP00000354739" "9606.ENSP00000354782" "9606.ENSP00000354813"
## [2413] "9606.ENSP00000354822" "9606.ENSP00000354826" "9606.ENSP00000354830"
## [2416] "9606.ENSP00000354850" "9606.ENSP00000354859" "9606.ENSP00000354876"
## [2419] "9606.ENSP00000354900" "9606.ENSP00000354916" "9606.ENSP00000354923"
## [2422] "9606.ENSP00000354952" "9606.ENSP00000354982" "9606.ENSP00000354995"
## [2425] "9606.ENSP00000355031" "9606.ENSP00000355046" "9606.ENSP00000355110"
## [2428] "9606.ENSP00000355124" "9606.ENSP00000355208" "9606.ENSP00000355231"
## [2431] "9606.ENSP00000355249" "9606.ENSP00000355261" "9606.ENSP00000355317"
## [2434] "9606.ENSP00000355330" "9606.ENSP00000355361" "9606.ENSP00000355370"
## [2437] "9606.ENSP00000355374" "9606.ENSP00000355465" "9606.ENSP00000355511"
## [2440] "9606.ENSP00000355517" "9606.ENSP00000355518" "9606.ENSP00000355536"
## [2443] "9606.ENSP00000355566" "9606.ENSP00000355568" "9606.ENSP00000355601"
## [2446] "9606.ENSP00000355627" "9606.ENSP00000355645" "9606.ENSP00000355718"
## [2449] "9606.ENSP00000355739" "9606.ENSP00000355747" "9606.ENSP00000355751"
## [2452] "9606.ENSP00000355759" "9606.ENSP00000355775" "9606.ENSP00000355778"
## [2455] "9606.ENSP00000355809" "9606.ENSP00000355865" "9606.ENSP00000355890"
## [2458] "9606.ENSP00000355896" "9606.ENSP00000355922" "9606.ENSP00000355924"
## [2461] "9606.ENSP00000355958" "9606.ENSP00000355966" "9606.ENSP00000355988"
## [2464] "9606.ENSP00000356016" "9606.ENSP00000356022" "9606.ENSP00000356024"
## [2467] "9606.ENSP00000356064" "9606.ENSP00000356070" "9606.ENSP00000356087"
## [2470] "9606.ENSP00000356143" "9606.ENSP00000356150" "9606.ENSP00000356213"
## [2473] "9606.ENSP00000356224" "9606.ENSP00000356234" "9606.ENSP00000356256"
## [2476] "9606.ENSP00000356278" "9606.ENSP00000356286" "9606.ENSP00000356320"
## [2479] "9606.ENSP00000356346" "9606.ENSP00000356379" "9606.ENSP00000356399"
## [2482] "9606.ENSP00000356436" "9606.ENSP00000356438" "9606.ENSP00000356480"
## [2485] "9606.ENSP00000356505" "9606.ENSP00000356520" "9606.ENSP00000356529"
## [2488] "9606.ENSP00000356530" "9606.ENSP00000356545" "9606.ENSP00000356641"
## [2491] "9606.ENSP00000356671" "9606.ENSP00000356694" "9606.ENSP00000356771"
## [2494] "9606.ENSP00000356825" "9606.ENSP00000356832" "9606.ENSP00000356840"
## [2497] "9606.ENSP00000356848" "9606.ENSP00000356859" "9606.ENSP00000356919"
## [2500] "9606.ENSP00000356920" "9606.ENSP00000356940" "9606.ENSP00000356953"
## [2503] "9606.ENSP00000356954" "9606.ENSP00000356958" "9606.ENSP00000356985"
## [2506] "9606.ENSP00000356999" "9606.ENSP00000357025" "9606.ENSP00000357047"
## [2509] "9606.ENSP00000357066" "9606.ENSP00000357112" "9606.ENSP00000357113"
## [2512] "9606.ENSP00000357122" "9606.ENSP00000357123" "9606.ENSP00000357130"
## [2515] "9606.ENSP00000357175" "9606.ENSP00000357178" "9606.ENSP00000357189"
## [2518] "9606.ENSP00000357206" "9606.ENSP00000357283" "9606.ENSP00000357348"
## [2521] "9606.ENSP00000357380" "9606.ENSP00000357392" "9606.ENSP00000357429"
## [2524] "9606.ENSP00000357440" "9606.ENSP00000357459" "9606.ENSP00000357470"
## [2527] "9606.ENSP00000357494" "9606.ENSP00000357516" "9606.ENSP00000357555"
## [2530] "9606.ENSP00000357615" "9606.ENSP00000357622" "9606.ENSP00000357625"
## [2533] "9606.ENSP00000357643" "9606.ENSP00000357697" "9606.ENSP00000357708"
## [2536] "9606.ENSP00000357721" "9606.ENSP00000357727" "9606.ENSP00000357731"
## [2539] "9606.ENSP00000357748" "9606.ENSP00000357753" "9606.ENSP00000357789"
## [2542] "9606.ENSP00000357799" "9606.ENSP00000357838" "9606.ENSP00000357844"
## [2545] "9606.ENSP00000357858" "9606.ENSP00000357879" "9606.ENSP00000357880"
## [2548] "9606.ENSP00000357905" "9606.ENSP00000357981" "9606.ENSP00000358022"
## [2551] "9606.ENSP00000358071" "9606.ENSP00000358081" "9606.ENSP00000358089"
## [2554] "9606.ENSP00000358092" "9606.ENSP00000358131" "9606.ENSP00000358140"
## [2557] "9606.ENSP00000358153" "9606.ENSP00000358162" "9606.ENSP00000358323"
## [2560] "9606.ENSP00000358327" "9606.ENSP00000358335" "9606.ENSP00000358417"
## [2563] "9606.ENSP00000358470" "9606.ENSP00000358474" "9606.ENSP00000358490"
## [2566] "9606.ENSP00000358501" "9606.ENSP00000358511" "9606.ENSP00000358525"
## [2569] "9606.ENSP00000358531" "9606.ENSP00000358548" "9606.ENSP00000358554"
## [2572] "9606.ENSP00000358563" "9606.ENSP00000358571" "9606.ENSP00000358596"
## [2575] "9606.ENSP00000358622" "9606.ENSP00000358635" "9606.ENSP00000358698"
## [2578] "9606.ENSP00000358716" "9606.ENSP00000358770" "9606.ENSP00000358813"
## [2581] "9606.ENSP00000358854" "9606.ENSP00000358903" "9606.ENSP00000358918"
## [2584] "9606.ENSP00000358919" "9606.ENSP00000358967" "9606.ENSP00000358983"
## [2587] "9606.ENSP00000358994" "9606.ENSP00000358997" "9606.ENSP00000359013"
## [2590] "9606.ENSP00000359035" "9606.ENSP00000359073" "9606.ENSP00000359095"
## [2593] "9606.ENSP00000359206" "9606.ENSP00000359211" "9606.ENSP00000359212"
## [2596] "9606.ENSP00000359245" "9606.ENSP00000359258" "9606.ENSP00000359285"
## [2599] "9606.ENSP00000359290" "9606.ENSP00000359301" "9606.ENSP00000359307"
## [2602] "9606.ENSP00000359321" "9606.ENSP00000359345" "9606.ENSP00000359380"
## [2605] "9606.ENSP00000359424" "9606.ENSP00000359478" "9606.ENSP00000359504"
## [2608] "9606.ENSP00000359506" "9606.ENSP00000359531" "9606.ENSP00000359532"
## [2611] "9606.ENSP00000359567" "9606.ENSP00000359596" "9606.ENSP00000359630"
## [2614] "9606.ENSP00000359635" "9606.ENSP00000359663" "9606.ENSP00000359693"
## [2617] "9606.ENSP00000359727" "9606.ENSP00000359910" "9606.ENSP00000359939"
## [2620] "9606.ENSP00000359991" "9606.ENSP00000359998" "9606.ENSP00000360020"
## [2623] "9606.ENSP00000360025" "9606.ENSP00000360034" "9606.ENSP00000360141"
## [2626] "9606.ENSP00000360157" "9606.ENSP00000360163" "9606.ENSP00000360181"
## [2629] "9606.ENSP00000360210" "9606.ENSP00000360216" "9606.ENSP00000360250"
## [2632] "9606.ENSP00000360266" "9606.ENSP00000360269" "9606.ENSP00000360286"
## [2635] "9606.ENSP00000360290" "9606.ENSP00000360310" "9606.ENSP00000360316"
## [2638] "9606.ENSP00000360472" "9606.ENSP00000360492" "9606.ENSP00000360493"
## [2641] "9606.ENSP00000360498" "9606.ENSP00000360515" "9606.ENSP00000360540"
## [2644] "9606.ENSP00000360613" "9606.ENSP00000360635" "9606.ENSP00000360671"
## [2647] "9606.ENSP00000360683" "9606.ENSP00000360773" "9606.ENSP00000360843"
## [2650] "9606.ENSP00000360869" "9606.ENSP00000360876" "9606.ENSP00000360891"
## [2653] "9606.ENSP00000360922" "9606.ENSP00000360938" "9606.ENSP00000361021"
## [2656] "9606.ENSP00000361043" "9606.ENSP00000361066" "9606.ENSP00000361120"
## [2659] "9606.ENSP00000361125" "9606.ENSP00000361162" "9606.ENSP00000361170"
## [2662] "9606.ENSP00000361186" "9606.ENSP00000361245" "9606.ENSP00000361264"
## [2665] "9606.ENSP00000361266" "9606.ENSP00000361275" "9606.ENSP00000361280"
## [2668] "9606.ENSP00000361298" "9606.ENSP00000361310" "9606.ENSP00000361359"
## [2671] "9606.ENSP00000361405" "9606.ENSP00000361423" "9606.ENSP00000361473"
## [2674] "9606.ENSP00000361548" "9606.ENSP00000361554" "9606.ENSP00000361626"
## [2677] "9606.ENSP00000361635" "9606.ENSP00000361668" "9606.ENSP00000361672"
## [2680] "9606.ENSP00000361725" "9606.ENSP00000361777" "9606.ENSP00000361818"
## [2683] "9606.ENSP00000361824" "9606.ENSP00000361845" "9606.ENSP00000361850"
## [2686] "9606.ENSP00000361875" "9606.ENSP00000361892" "9606.ENSP00000362010"
## [2689] "9606.ENSP00000362057" "9606.ENSP00000362082" "9606.ENSP00000362221"
## [2692] "9606.ENSP00000362287" "9606.ENSP00000362296" "9606.ENSP00000362299"
## [2695] "9606.ENSP00000362300" "9606.ENSP00000362306" "9606.ENSP00000362329"
## [2698] "9606.ENSP00000362361" "9606.ENSP00000362409" "9606.ENSP00000362410"
## [2701] "9606.ENSP00000362413" "9606.ENSP00000362441" "9606.ENSP00000362446"
## [2704] "9606.ENSP00000362481" "9606.ENSP00000362576" "9606.ENSP00000362578"
## [2707] "9606.ENSP00000362592" "9606.ENSP00000362608" "9606.ENSP00000362609"
## [2710] "9606.ENSP00000362649" "9606.ENSP00000362674" "9606.ENSP00000362687"
## [2713] "9606.ENSP00000362702" "9606.ENSP00000362728" "9606.ENSP00000362744"
## [2716] "9606.ENSP00000362751" "9606.ENSP00000362762" "9606.ENSP00000362768"
## [2719] "9606.ENSP00000362773" "9606.ENSP00000362795" "9606.ENSP00000362807"
## [2722] "9606.ENSP00000362817" "9606.ENSP00000362824" "9606.ENSP00000362924"
## [2725] "9606.ENSP00000362931" "9606.ENSP00000362994" "9606.ENSP00000363003"
## [2728] "9606.ENSP00000363018" "9606.ENSP00000363019" "9606.ENSP00000363021"
## [2731] "9606.ENSP00000363081" "9606.ENSP00000363089" "9606.ENSP00000363092"
## [2734] "9606.ENSP00000363095" "9606.ENSP00000363115" "9606.ENSP00000363124"
## [2737] "9606.ENSP00000363128" "9606.ENSP00000363193" "9606.ENSP00000363205"
## [2740] "9606.ENSP00000363318" "9606.ENSP00000363330" "9606.ENSP00000363377"
## [2743] "9606.ENSP00000363390" "9606.ENSP00000363395" "9606.ENSP00000363397"
## [2746] "9606.ENSP00000363435" "9606.ENSP00000363458" "9606.ENSP00000363500"
## [2749] "9606.ENSP00000363512" "9606.ENSP00000363640" "9606.ENSP00000363641"
## [2752] "9606.ENSP00000363676" "9606.ENSP00000363680" "9606.ENSP00000363694"
## [2755] "9606.ENSP00000363763" "9606.ENSP00000363779" "9606.ENSP00000363787"
## [2758] "9606.ENSP00000363804" "9606.ENSP00000363822" "9606.ENSP00000363827"
## [2761] "9606.ENSP00000363868" "9606.ENSP00000363921" "9606.ENSP00000363970"
## [2764] "9606.ENSP00000363998" "9606.ENSP00000364126" "9606.ENSP00000364133"
## [2767] "9606.ENSP00000364163" "9606.ENSP00000364204" "9606.ENSP00000364212"
## [2770] "9606.ENSP00000364252" "9606.ENSP00000364265" "9606.ENSP00000364270"
## [2773] "9606.ENSP00000364277" "9606.ENSP00000364310" "9606.ENSP00000364389"
## [2776] "9606.ENSP00000364398" "9606.ENSP00000364519" "9606.ENSP00000364524"
## [2779] "9606.ENSP00000364589" "9606.ENSP00000364595" "9606.ENSP00000364597"
## [2782] "9606.ENSP00000364649" "9606.ENSP00000364687" "9606.ENSP00000364699"
## [2785] "9606.ENSP00000364709" "9606.ENSP00000364731" "9606.ENSP00000364742"
## [2788] "9606.ENSP00000364777" "9606.ENSP00000364794" "9606.ENSP00000364801"
## [2791] "9606.ENSP00000364802" "9606.ENSP00000364805" "9606.ENSP00000364839"
## [2794] "9606.ENSP00000364847" "9606.ENSP00000364859" "9606.ENSP00000364893"
## [2797] "9606.ENSP00000364898" "9606.ENSP00000364912" "9606.ENSP00000364929"
## [2800] "9606.ENSP00000364976" "9606.ENSP00000364979" "9606.ENSP00000364995"
## [2803] "9606.ENSP00000365012" "9606.ENSP00000365016" "9606.ENSP00000365025"
## [2806] "9606.ENSP00000365048" "9606.ENSP00000365131" "9606.ENSP00000365175"
## [2809] "9606.ENSP00000365227" "9606.ENSP00000365233" "9606.ENSP00000365280"
## [2812] "9606.ENSP00000365380" "9606.ENSP00000365397" "9606.ENSP00000365435"
## [2815] "9606.ENSP00000365439" "9606.ENSP00000365462" "9606.ENSP00000365528"
## [2818] "9606.ENSP00000365588" "9606.ENSP00000365682" "9606.ENSP00000365692"
## [2821] "9606.ENSP00000365745" "9606.ENSP00000365759" "9606.ENSP00000365775"
## [2824] "9606.ENSP00000365844" "9606.ENSP00000365851" "9606.ENSP00000365858"
## [2827] "9606.ENSP00000365877" "9606.ENSP00000366005" "9606.ENSP00000366032"
## [2830] "9606.ENSP00000366084" "9606.ENSP00000366124" "9606.ENSP00000366157"
## [2833] "9606.ENSP00000366237" "9606.ENSP00000366244" "9606.ENSP00000366271"
## [2836] "9606.ENSP00000366306" "9606.ENSP00000366347" "9606.ENSP00000366395"
## [2839] "9606.ENSP00000366410" "9606.ENSP00000366413" "9606.ENSP00000366416"
## [2842] "9606.ENSP00000366434" "9606.ENSP00000366466" "9606.ENSP00000366482"
## [2845] "9606.ENSP00000366493" "9606.ENSP00000366509" "9606.ENSP00000366563"
## [2848] "9606.ENSP00000366581" "9606.ENSP00000366915" "9606.ENSP00000366927"
## [2851] "9606.ENSP00000367029" "9606.ENSP00000367030" "9606.ENSP00000367059"
## [2854] "9606.ENSP00000367123" "9606.ENSP00000367202" "9606.ENSP00000367203"
## [2857] "9606.ENSP00000367207" "9606.ENSP00000367248" "9606.ENSP00000367265"
## [2860] "9606.ENSP00000367309" "9606.ENSP00000367406" "9606.ENSP00000367407"
## [2863] "9606.ENSP00000367408" "9606.ENSP00000367446" "9606.ENSP00000367454"
## [2866] "9606.ENSP00000367545" "9606.ENSP00000367608" "9606.ENSP00000367615"
## [2869] "9606.ENSP00000367746" "9606.ENSP00000367787" "9606.ENSP00000367797"
## [2872] "9606.ENSP00000367802" "9606.ENSP00000367817" "9606.ENSP00000367828"
## [2875] "9606.ENSP00000367891" "9606.ENSP00000367910" "9606.ENSP00000367972"
## [2878] "9606.ENSP00000367991" "9606.ENSP00000368020" "9606.ENSP00000368030"
## [2881] "9606.ENSP00000368079" "9606.ENSP00000368104" "9606.ENSP00000368169"
## [2884] "9606.ENSP00000368190" "9606.ENSP00000368253" "9606.ENSP00000368332"
## [2887] "9606.ENSP00000368349" "9606.ENSP00000368401" "9606.ENSP00000368438"
## [2890] "9606.ENSP00000368450" "9606.ENSP00000368552" "9606.ENSP00000368572"
## [2893] "9606.ENSP00000368632" "9606.ENSP00000368646" "9606.ENSP00000368664"
## [2896] "9606.ENSP00000368667" "9606.ENSP00000368682" "9606.ENSP00000368683"
## [2899] "9606.ENSP00000368686" "9606.ENSP00000368699" "9606.ENSP00000368727"
## [2902] "9606.ENSP00000368752" "9606.ENSP00000368759" "9606.ENSP00000368856"
## [2905] "9606.ENSP00000368880" "9606.ENSP00000368881" "9606.ENSP00000368884"
## [2908] "9606.ENSP00000368924" "9606.ENSP00000368959" "9606.ENSP00000369038"
## [2911] "9606.ENSP00000369050" "9606.ENSP00000369071" "9606.ENSP00000369100"
## [2914] "9606.ENSP00000369127" "9606.ENSP00000369129" "9606.ENSP00000369131"
## [2917] "9606.ENSP00000369141" "9606.ENSP00000369213" "9606.ENSP00000369274"
## [2920] "9606.ENSP00000369299" "9606.ENSP00000369351" "9606.ENSP00000369375"
## [2923] "9606.ENSP00000369411" "9606.ENSP00000369419" "9606.ENSP00000369424"
## [2926] "9606.ENSP00000369442" "9606.ENSP00000369460" "9606.ENSP00000369497"
## [2929] "9606.ENSP00000369519" "9606.ENSP00000369554" "9606.ENSP00000369581"
## [2932] "9606.ENSP00000369643" "9606.ENSP00000369654" "9606.ENSP00000369695"
## [2935] "9606.ENSP00000369703" "9606.ENSP00000369716" "9606.ENSP00000369757"
## [2938] "9606.ENSP00000369816" "9606.ENSP00000369889" "9606.ENSP00000369897"
## [2941] "9606.ENSP00000370003" "9606.ENSP00000370034" "9606.ENSP00000370074"
## [2944] "9606.ENSP00000370083" "9606.ENSP00000370104" "9606.ENSP00000370109"
## [2947] "9606.ENSP00000370115" "9606.ENSP00000370128" "9606.ENSP00000370129"
## [2950] "9606.ENSP00000370151" "9606.ENSP00000370253" "9606.ENSP00000370254"
## [2953] "9606.ENSP00000370270" "9606.ENSP00000370340" "9606.ENSP00000370343"
## [2956] "9606.ENSP00000370376" "9606.ENSP00000370381" "9606.ENSP00000370408"
## [2959] "9606.ENSP00000370410" "9606.ENSP00000370421" "9606.ENSP00000370439"
## [2962] "9606.ENSP00000370473" "9606.ENSP00000370571" "9606.ENSP00000370588"
## [2965] "9606.ENSP00000370616" "9606.ENSP00000370710" "9606.ENSP00000370767"
## [2968] "9606.ENSP00000370839" "9606.ENSP00000370867" "9606.ENSP00000370880"
## [2971] "9606.ENSP00000370912" "9606.ENSP00000370936" "9606.ENSP00000370938"
## [2974] "9606.ENSP00000370968" "9606.ENSP00000370989" "9606.ENSP00000371003"
## [2977] "9606.ENSP00000371067" "9606.ENSP00000371110" "9606.ENSP00000371138"
## [2980] "9606.ENSP00000371236" "9606.ENSP00000371321" "9606.ENSP00000371341"
## [2983] "9606.ENSP00000371419" "9606.ENSP00000371420" "9606.ENSP00000371432"
## [2986] "9606.ENSP00000371475" "9606.ENSP00000371517" "9606.ENSP00000371554"
## [2989] "9606.ENSP00000371790" "9606.ENSP00000371798" "9606.ENSP00000371985"
## [2992] "9606.ENSP00000372023" "9606.ENSP00000372025" "9606.ENSP00000372035"
## [2995] "9606.ENSP00000372088" "9606.ENSP00000372170" "9606.ENSP00000372191"
## [2998] "9606.ENSP00000372221" "9606.ENSP00000372224" "9606.ENSP00000372313"
## [3001] "9606.ENSP00000372322" "9606.ENSP00000372347" "9606.ENSP00000372437"
## [3004] "9606.ENSP00000372547" "9606.ENSP00000372654" "9606.ENSP00000373244"
## [3007] "9606.ENSP00000373298" "9606.ENSP00000373301" "9606.ENSP00000373354"
## [3010] "9606.ENSP00000373477" "9606.ENSP00000373487" "9606.ENSP00000373518"
## [3013] "9606.ENSP00000373570" "9606.ENSP00000373637" "9606.ENSP00000373691"
## [3016] "9606.ENSP00000373700" "9606.ENSP00000373772" "9606.ENSP00000373864"
## [3019] "9606.ENSP00000373952" "9606.ENSP00000374013" "9606.ENSP00000374145"
## [3022] "9606.ENSP00000374212" "9606.ENSP00000374265" "9606.ENSP00000374357"
## [3025] "9606.ENSP00000374455" "9606.ENSP00000374467" "9606.ENSP00000374529"
## [3028] "9606.ENSP00000374574" "9606.ENSP00000374592" "9606.ENSP00000375557"
## [3031] "9606.ENSP00000375660" "9606.ENSP00000375730" "9606.ENSP00000375795"
## [3034] "9606.ENSP00000375809" "9606.ENSP00000375863" "9606.ENSP00000375872"
## [3037] "9606.ENSP00000375892" "9606.ENSP00000375921" "9606.ENSP00000375956"
## [3040] "9606.ENSP00000375977" "9606.ENSP00000376076" "9606.ENSP00000376127"
## [3043] "9606.ENSP00000376150" "9606.ENSP00000376215" "9606.ENSP00000376258"
## [3046] "9606.ENSP00000376317" "9606.ENSP00000376322" "9606.ENSP00000376436"
## [3049] "9606.ENSP00000376500" "9606.ENSP00000376544" "9606.ENSP00000376568"
## [3052] "9606.ENSP00000376609" "9606.ENSP00000376611" "9606.ENSP00000376684"
## [3055] "9606.ENSP00000376765" "9606.ENSP00000376786" "9606.ENSP00000376793"
## [3058] "9606.ENSP00000376808" "9606.ENSP00000376822" "9606.ENSP00000376848"
## [3061] "9606.ENSP00000376865" "9606.ENSP00000376886" "9606.ENSP00000376889"
## [3064] "9606.ENSP00000376914" "9606.ENSP00000376943" "9606.ENSP00000376965"
## [3067] "9606.ENSP00000377047" "9606.ENSP00000377218" "9606.ENSP00000377252"
## [3070] "9606.ENSP00000377265" "9606.ENSP00000377298" "9606.ENSP00000377372"
## [3073] "9606.ENSP00000377401" "9606.ENSP00000377409" "9606.ENSP00000377446"
## [3076] "9606.ENSP00000377492" "9606.ENSP00000377496" "9606.ENSP00000377527"
## [3079] "9606.ENSP00000377640" "9606.ENSP00000377721" "9606.ENSP00000377783"
## [3082] "9606.ENSP00000377793" "9606.ENSP00000377823" "9606.ENSP00000377833"
## [3085] "9606.ENSP00000377836" "9606.ENSP00000377865" "9606.ENSP00000377900"
## [3088] "9606.ENSP00000377944" "9606.ENSP00000377958" "9606.ENSP00000377995"
## [3091] "9606.ENSP00000378130" "9606.ENSP00000378152" "9606.ENSP00000378181"
## [3094] "9606.ENSP00000378295" "9606.ENSP00000378307" "9606.ENSP00000378323"
## [3097] "9606.ENSP00000378349" "9606.ENSP00000378364" "9606.ENSP00000378394"
## [3100] "9606.ENSP00000378400" "9606.ENSP00000378414" "9606.ENSP00000378485"
## [3103] "9606.ENSP00000378505" "9606.ENSP00000378517" "9606.ENSP00000378529"
## [3106] "9606.ENSP00000378699" "9606.ENSP00000378702" "9606.ENSP00000378735"
## [3109] "9606.ENSP00000378856" "9606.ENSP00000378957" "9606.ENSP00000379003"
## [3112] "9606.ENSP00000379042" "9606.ENSP00000379086" "9606.ENSP00000379092"
## [3115] "9606.ENSP00000379110" "9606.ENSP00000379138" "9606.ENSP00000379140"
## [3118] "9606.ENSP00000379144" "9606.ENSP00000379157" "9606.ENSP00000379204"
## [3121] "9606.ENSP00000379213" "9606.ENSP00000379228" "9606.ENSP00000379258"
## [3124] "9606.ENSP00000379330" "9606.ENSP00000379441" "9606.ENSP00000379616"
## [3127] "9606.ENSP00000379658" "9606.ENSP00000379680" "9606.ENSP00000379834"
## [3130] "9606.ENSP00000379931" "9606.ENSP00000379999" "9606.ENSP00000380024"
## [3133] "9606.ENSP00000380033" "9606.ENSP00000380073" "9606.ENSP00000380150"
## [3136] "9606.ENSP00000380156" "9606.ENSP00000380193" "9606.ENSP00000380227"
## [3139] "9606.ENSP00000380252" "9606.ENSP00000380256" "9606.ENSP00000380313"
## [3142] "9606.ENSP00000380349" "9606.ENSP00000380378" "9606.ENSP00000380414"
## [3145] "9606.ENSP00000380494" "9606.ENSP00000380505" "9606.ENSP00000380514"
## [3148] "9606.ENSP00000380552" "9606.ENSP00000380597" "9606.ENSP00000380605"
## [3151] "9606.ENSP00000380781" "9606.ENSP00000380897" "9606.ENSP00000381008"
## [3154] "9606.ENSP00000381045" "9606.ENSP00000381066" "9606.ENSP00000381097"
## [3157] "9606.ENSP00000381098" "9606.ENSP00000381105" "9606.ENSP00000381214"
## [3160] "9606.ENSP00000381216" "9606.ENSP00000381282" "9606.ENSP00000381588"
## [3163] "9606.ENSP00000381599" "9606.ENSP00000381607" "9606.ENSP00000381657"
## [3166] "9606.ENSP00000381717" "9606.ENSP00000381740" "9606.ENSP00000381793"
## [3169] "9606.ENSP00000381932" "9606.ENSP00000381992" "9606.ENSP00000382004"
## [3172] "9606.ENSP00000382133" "9606.ENSP00000382342" "9606.ENSP00000382390"
## [3175] "9606.ENSP00000382423" "9606.ENSP00000382659" "9606.ENSP00000382688"
## [3178] "9606.ENSP00000382697" "9606.ENSP00000382714" "9606.ENSP00000382834"
## [3181] "9606.ENSP00000382840" "9606.ENSP00000382863" "9606.ENSP00000383042"
## [3184] "9606.ENSP00000383199" "9606.ENSP00000383295" "9606.ENSP00000383365"
## [3187] "9606.ENSP00000383516" "9606.ENSP00000383611" "9606.ENSP00000383820"
## [3190] "9606.ENSP00000383900" "9606.ENSP00000383986" "9606.ENSP00000384018"
## [3193] "9606.ENSP00000384026" "9606.ENSP00000384048" "9606.ENSP00000384109"
## [3196] "9606.ENSP00000384115" "9606.ENSP00000384144" "9606.ENSP00000384223"
## [3199] "9606.ENSP00000384273" "9606.ENSP00000384408" "9606.ENSP00000384432"
## [3202] "9606.ENSP00000384442" "9606.ENSP00000384554" "9606.ENSP00000384625"
## [3205] "9606.ENSP00000384665" "9606.ENSP00000384675" "9606.ENSP00000384708"
## [3208] "9606.ENSP00000384774" "9606.ENSP00000384792" "9606.ENSP00000384823"
## [3211] "9606.ENSP00000384863" "9606.ENSP00000384881" "9606.ENSP00000385021"
## [3214] "9606.ENSP00000385045" "9606.ENSP00000385057" "9606.ENSP00000385269"
## [3217] "9606.ENSP00000385328" "9606.ENSP00000385461" "9606.ENSP00000385551"
## [3220] "9606.ENSP00000385571" "9606.ENSP00000385632" "9606.ENSP00000385636"
## [3223] "9606.ENSP00000385638" "9606.ENSP00000385720" "9606.ENSP00000385721"
## [3226] "9606.ENSP00000385751" "9606.ENSP00000385834" "9606.ENSP00000385892"
## [3229] "9606.ENSP00000386165" "9606.ENSP00000386227" "9606.ENSP00000386341"
## [3232] "9606.ENSP00000386444" "9606.ENSP00000386531" "9606.ENSP00000386541"
## [3235] "9606.ENSP00000386759" "9606.ENSP00000386810" "9606.ENSP00000386845"
## [3238] "9606.ENSP00000386884" "9606.ENSP00000386896" "9606.ENSP00000386951"
## [3241] "9606.ENSP00000387077" "9606.ENSP00000387261" "9606.ENSP00000387262"
## [3244] "9606.ENSP00000387282" "9606.ENSP00000387307" "9606.ENSP00000387356"
## [3247] "9606.ENSP00000387641" "9606.ENSP00000387662" "9606.ENSP00000387699"
## [3250] "9606.ENSP00000387966" "9606.ENSP00000388107" "9606.ENSP00000388311"
## [3253] "9606.ENSP00000388548" "9606.ENSP00000388566" "9606.ENSP00000388648"
## [3256] "9606.ENSP00000388910" "9606.ENSP00000389128" "9606.ENSP00000389140"
## [3259] "9606.ENSP00000389338" "9606.ENSP00000389381" "9606.ENSP00000389414"
## [3262] "9606.ENSP00000389787" "9606.ENSP00000390158" "9606.ENSP00000390475"
## [3265] "9606.ENSP00000390478" "9606.ENSP00000390500" "9606.ENSP00000390621"
## [3268] "9606.ENSP00000391249" "9606.ENSP00000391592" "9606.ENSP00000391669"
## [3271] "9606.ENSP00000391676" "9606.ENSP00000391774" "9606.ENSP00000391826"
## [3274] "9606.ENSP00000392395" "9606.ENSP00000392423" "9606.ENSP00000392617"
## [3277] "9606.ENSP00000392762" "9606.ENSP00000392812" "9606.ENSP00000392985"
## [3280] "9606.ENSP00000393154" "9606.ENSP00000393183" "9606.ENSP00000393262"
## [3283] "9606.ENSP00000393312" "9606.ENSP00000393596" "9606.ENSP00000393762"
## [3286] "9606.ENSP00000394085" "9606.ENSP00000394624" "9606.ENSP00000394757"
## [3289] "9606.ENSP00000394791" "9606.ENSP00000394794" "9606.ENSP00000394863"
## [3292] "9606.ENSP00000394932" "9606.ENSP00000395359" "9606.ENSP00000395449"
## [3295] "9606.ENSP00000395498" "9606.ENSP00000395535" "9606.ENSP00000395772"
## [3298] "9606.ENSP00000395929" "9606.ENSP00000396052" "9606.ENSP00000396163"
## [3301] "9606.ENSP00000396259" "9606.ENSP00000396308" "9606.ENSP00000396538"
## [3304] "9606.ENSP00000396620" "9606.ENSP00000396704" "9606.ENSP00000396749"
## [3307] "9606.ENSP00000396954" "9606.ENSP00000397157" "9606.ENSP00000397297"
## [3310] "9606.ENSP00000397435" "9606.ENSP00000397552" "9606.ENSP00000397911"
## [3313] "9606.ENSP00000398124" "9606.ENSP00000398131" "9606.ENSP00000398350"
## [3316] "9606.ENSP00000398495" "9606.ENSP00000398516" "9606.ENSP00000398632"
## [3319] "9606.ENSP00000398655" "9606.ENSP00000398698" "9606.ENSP00000398736"
## [3322] "9606.ENSP00000399518" "9606.ENSP00000399903" "9606.ENSP00000399968"
## [3325] "9606.ENSP00000399982" "9606.ENSP00000399985" "9606.ENSP00000400010"
## [3328] "9606.ENSP00000400088" "9606.ENSP00000400142" "9606.ENSP00000400175"
## [3331] "9606.ENSP00000400365" "9606.ENSP00000401303" "9606.ENSP00000401371"
## [3334] "9606.ENSP00000401399" "9606.ENSP00000401437" "9606.ENSP00000401445"
## [3337] "9606.ENSP00000401450" "9606.ENSP00000401566" "9606.ENSP00000401678"
## [3340] "9606.ENSP00000401721" "9606.ENSP00000401802" "9606.ENSP00000401946"
## [3343] "9606.ENSP00000402060" "9606.ENSP00000402084" "9606.ENSP00000402257"
## [3346] "9606.ENSP00000402515" "9606.ENSP00000402551" "9606.ENSP00000402697"
## [3349] "9606.ENSP00000402758" "9606.ENSP00000403459" "9606.ENSP00000403524"
## [3352] "9606.ENSP00000403536" "9606.ENSP00000403649" "9606.ENSP00000403712"
## [3355] "9606.ENSP00000403852" "9606.ENSP00000403975" "9606.ENSP00000404029"
## [3358] "9606.ENSP00000404121" "9606.ENSP00000404503" "9606.ENSP00000404676"
## [3361] "9606.ENSP00000405176" "9606.ENSP00000405455" "9606.ENSP00000405726"
## [3364] "9606.ENSP00000405890" "9606.ENSP00000405926" "9606.ENSP00000405963"
## [3367] "9606.ENSP00000405965" "9606.ENSP00000406037" "9606.ENSP00000406046"
## [3370] "9606.ENSP00000406162" "9606.ENSP00000406293" "9606.ENSP00000406490"
## [3373] "9606.ENSP00000406738" "9606.ENSP00000406861" "9606.ENSP00000406955"
## [3376] "9606.ENSP00000407323" "9606.ENSP00000407353" "9606.ENSP00000407375"
## [3379] "9606.ENSP00000407546" "9606.ENSP00000408342" "9606.ENSP00000408411"
## [3382] "9606.ENSP00000408581" "9606.ENSP00000408617" "9606.ENSP00000408632"
## [3385] "9606.ENSP00000408695" "9606.ENSP00000408994" "9606.ENSP00000409007"
## [3388] "9606.ENSP00000409016" "9606.ENSP00000409346" "9606.ENSP00000409555"
## [3391] "9606.ENSP00000409581" "9606.ENSP00000410076" "9606.ENSP00000410198"
## [3394] "9606.ENSP00000410294" "9606.ENSP00000410452" "9606.ENSP00000410715"
## [3397] "9606.ENSP00000410758" "9606.ENSP00000410943" "9606.ENSP00000411397"
## [3400] "9606.ENSP00000411532" "9606.ENSP00000411552" "9606.ENSP00000412064"
## [3403] "9606.ENSP00000412237" "9606.ENSP00000412292" "9606.ENSP00000412324"
## [3406] "9606.ENSP00000412922" "9606.ENSP00000414303" "9606.ENSP00000414321"
## [3409] "9606.ENSP00000414516" "9606.ENSP00000415032" "9606.ENSP00000415183"
## [3412] "9606.ENSP00000415430" "9606.ENSP00000415481" "9606.ENSP00000415786"
## [3415] "9606.ENSP00000415900" "9606.ENSP00000415941" "9606.ENSP00000416040"
## [3418] "9606.ENSP00000416193" "9606.ENSP00000416293" "9606.ENSP00000416330"
## [3421] "9606.ENSP00000416561" "9606.ENSP00000417183" "9606.ENSP00000417257"
## [3424] "9606.ENSP00000417281" "9606.ENSP00000417404" "9606.ENSP00000417498"
## [3427] "9606.ENSP00000417517" "9606.ENSP00000417696" "9606.ENSP00000417864"
## [3430] "9606.ENSP00000417980" "9606.ENSP00000418081" "9606.ENSP00000418082"
## [3433] "9606.ENSP00000418112" "9606.ENSP00000418191" "9606.ENSP00000418287"
## [3436] "9606.ENSP00000418397" "9606.ENSP00000418447" "9606.ENSP00000418842"
## [3439] "9606.ENSP00000418960" "9606.ENSP00000419325" "9606.ENSP00000419425"
## [3442] "9606.ENSP00000419446" "9606.ENSP00000419471" "9606.ENSP00000419485"
## [3445] "9606.ENSP00000419494" "9606.ENSP00000419692" "9606.ENSP00000419782"
## [3448] "9606.ENSP00000419923" "9606.ENSP00000419945" "9606.ENSP00000420194"
## [3451] "9606.ENSP00000420270" "9606.ENSP00000420294" "9606.ENSP00000420321"
## [3454] "9606.ENSP00000420381" "9606.ENSP00000420514" "9606.ENSP00000420588"
## [3457] "9606.ENSP00000421280" "9606.ENSP00000421592" "9606.ENSP00000421689"
## [3460] "9606.ENSP00000421799" "9606.ENSP00000422464" "9606.ENSP00000422533"
## [3463] "9606.ENSP00000422591" "9606.ENSP00000422753" "9606.ENSP00000423067"
## [3466] "9606.ENSP00000423673" "9606.ENSP00000424038" "9606.ENSP00000424048"
## [3469] "9606.ENSP00000424198" "9606.ENSP00000424838" "9606.ENSP00000425107"
## [3472] "9606.ENSP00000425133" "9606.ENSP00000425257" "9606.ENSP00000425493"
## [3475] "9606.ENSP00000425556" "9606.ENSP00000425561" "9606.ENSP00000425809"
## [3478] "9606.ENSP00000426103" "9606.ENSP00000426909" "9606.ENSP00000427015"
## [3481] "9606.ENSP00000427514" "9606.ENSP00000428205" "9606.ENSP00000428209"
## [3484] "9606.ENSP00000428340" "9606.ENSP00000428426" "9606.ENSP00000428657"
## [3487] "9606.ENSP00000428924" "9606.ENSP00000428982" "9606.ENSP00000429064"
## [3490] "9606.ENSP00000429084" "9606.ENSP00000429190" "9606.ENSP00000429344"
## [3493] "9606.ENSP00000429374" "9606.ENSP00000429633" "9606.ENSP00000429824"
## [3496] "9606.ENSP00000430276" "9606.ENSP00000430333" "9606.ENSP00000430432"
## [3499] "9606.ENSP00000430633" "9606.ENSP00000430684" "9606.ENSP00000430690"
## [3502] "9606.ENSP00000431254" "9606.ENSP00000431391" "9606.ENSP00000431418"
## [3505] "9606.ENSP00000431512" "9606.ENSP00000431872" "9606.ENSP00000432545"
## [3508] "9606.ENSP00000432743" "9606.ENSP00000432799" "9606.ENSP00000433459"
## [3511] "9606.ENSP00000433821" "9606.ENSP00000434279" "9606.ENSP00000434516"
## [3514] "9606.ENSP00000434614" "9606.ENSP00000435210" "9606.ENSP00000435412"
## [3517] "9606.ENSP00000435591" "9606.ENSP00000435777" "9606.ENSP00000435835"
## [3520] "9606.ENSP00000436426" "9606.ENSP00000436691" "9606.ENSP00000436786"
## [3523] "9606.ENSP00000436812" "9606.ENSP00000437910" "9606.ENSP00000437940"
## [3526] "9606.ENSP00000438144" "9606.ENSP00000438284" "9606.ENSP00000438468"
## [3529] "9606.ENSP00000438788" "9606.ENSP00000438875" "9606.ENSP00000439467"
## [3532] "9606.ENSP00000440586" "9606.ENSP00000440698" "9606.ENSP00000440847"
## [3535] "9606.ENSP00000441410" "9606.ENSP00000441462" "9606.ENSP00000441691"
## [3538] "9606.ENSP00000441875" "9606.ENSP00000441927" "9606.ENSP00000441954"
## [3541] "9606.ENSP00000442050" "9606.ENSP00000442057" "9606.ENSP00000442308"
## [3544] "9606.ENSP00000442477" "9606.ENSP00000442656" "9606.ENSP00000443194"
## [3547] "9606.ENSP00000443246" "9606.ENSP00000444408" "9606.ENSP00000444856"
## [3550] "9606.ENSP00000444972" "9606.ENSP00000445175" "9606.ENSP00000445366"
## [3553] "9606.ENSP00000445508" "9606.ENSP00000446280" "9606.ENSP00000446479"
## [3556] "9606.ENSP00000446916" "9606.ENSP00000447001" "9606.ENSP00000447149"
## [3559] "9606.ENSP00000447173" "9606.ENSP00000447378" "9606.ENSP00000447803"
## [3562] "9606.ENSP00000448165" "9606.ENSP00000448220" "9606.ENSP00000448323"
## [3565] "9606.ENSP00000449795" "9606.ENSP00000450527" "9606.ENSP00000450560"
## [3568] "9606.ENSP00000450635" "9606.ENSP00000450832" "9606.ENSP00000451040"
## [3571] "9606.ENSP00000451112" "9606.ENSP00000451145" "9606.ENSP00000451261"
## [3574] "9606.ENSP00000451320" "9606.ENSP00000451560" "9606.ENSP00000451605"
## [3577] "9606.ENSP00000452746" "9606.ENSP00000452780" "9606.ENSP00000452885"
## [3580] "9606.ENSP00000453144" "9606.ENSP00000454071" "9606.ENSP00000454861"
## [3583] "9606.ENSP00000456434" "9606.ENSP00000457230" "9606.ENSP00000457628"
## [3586] "9606.ENSP00000457706" "9606.ENSP00000457868" "9606.ENSP00000457881"
## [3589] "9606.ENSP00000458075" "9606.ENSP00000458537" "9606.ENSP00000459789"
## [3592] "9606.ENSP00000462664" "9606.ENSP00000462730" "9606.ENSP00000462795"
## [3595] "9606.ENSP00000462972" "9606.ENSP00000463999" "9606.ENSP00000464034"
## [3598] "9606.ENSP00000464149" "9606.ENSP00000464258" "9606.ENSP00000465655"
## [3601] "9606.ENSP00000465676" "9606.ENSP00000466214" "9606.ENSP00000466399"
## [3604] "9606.ENSP00000466834" "9606.ENSP00000467024" "9606.ENSP00000467176"
## [3607] "9606.ENSP00000467676" "9606.ENSP00000468367" "9606.ENSP00000470004"
## [3610] "9606.ENSP00000471914" "9606.ENSP00000472847" "9606.ENSP00000001008"
## [3613] "9606.ENSP00000000442" "9606.ENSP00000002829" "9606.ENSP00000472929"
## [3616] "9606.ENSP00000473172" "9606.ENSP00000468977" "9606.ENSP00000445868"
## [3619] "9606.ENSP00000468348" "9606.ENSP00000473233" "9606.ENSP00000472039"
## [3622] "9606.ENSP00000471505" "9606.ENSP00000468772" "9606.ENSP00000468389"
## [3625] "9606.ENSP00000461388" "9606.ENSP00000392204"
```

```r
string_db$get_interactions( c(tp53, atm) )
```

```
##                   from                   to neighborhood
## 1 9606.ENSP00000269305 9606.ENSP00000278616            0
##   neighborhood_transferred fusion cooccurence homology coexpression
## 1                        0      0           0        0            0
##   coexpression_transferred experiments experiments_transferred database
## 1                        0         999                       0      900
##   database_transferred textmining textmining_transferred combined_score
## 1                    0        973                     80            999
```



